<?php
// product_management.php
include 'dbconn.php'; // Include your database connection file

// Initialize variables for the form (for adding/editing)
$product_id = '';
$brand = '';
$model = '';
$size = '';
$price = '';
$stock = '';
$type = '';
$form_title = 'Add New Tyre Product';
$submit_button_text = 'Add Product';
$form_action = 'addproduct.php'; // Default action for adding

// Check if an 'id' is passed in the URL, indicating an edit operation
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch existing product data for editing
    $stmt = $conn->prepare("SELECT * FROM tyres WHERE id = ?");
    if ($stmt) { // Check if prepare was successful
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $brand = $row['brand'];
            $model = $row['model'];
            $size = $row['size'];
            $price = $row['price'];
            $stock = $row['stock'];
            $type = $row['type'];

            $form_title = 'Edit Tyre Product';
            $submit_button_text = 'Update Product';
            $form_action = 'edit_product.php'; // Action for updating
        } else {
            // Product not found, reset to add mode
            $product_id = '';
            // You might want to add a user-friendly error message here (e.g., in an alert)
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">Product not found. Switching to add mode.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>';
        }
        $stmt->close();
    } else {
        error_log("Error preparing product fetch statement: " . $conn->error);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">Database error during edit preparation.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    }
}

// Handle success/error messages from redirects
$message = '';
$alert_type = '';
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'added') {
        $message = 'Product added successfully!';
        $alert_type = 'success';
    } elseif ($_GET['success'] == 'updated') {
        $message = 'Product updated successfully!';
        $alert_type = 'success';
    } elseif ($_GET['success'] == 'deleted') {
        $message = 'Product deleted successfully!';
        $alert_type = 'success';
    }
} elseif (isset($_GET['error'])) {
    if ($_GET['error'] == 'invalid_id') {
        $message = 'Error: Invalid product ID for deletion.';
        $alert_type = 'danger';
    } elseif ($_GET['error'] == 'delete_failed') {
        $message = 'Error: Failed to delete product.';
        $alert_type = 'danger';
    } elseif ($_GET['error'] == 'db_error') {
        $message = 'A database error occurred.';
        $alert_type = 'danger';
    }
}


// Fetch all existing tyre products for display
$tyre_products = [];
$result_products = $conn->query("SELECT * FROM tyres ORDER BY brand ASC, model ASC");
if ($result_products) {
    while ($row = $result_products->fetch_assoc()) {
        $tyre_products[] = $row;
    }
    $result_products->free(); // Free the result set
} else {
    error_log("Error fetching products: " . $conn->error);
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">Could not retrieve product list.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
}

$conn->close(); // Close the database connection after all operations
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tyre Product Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
            font-size: 14px;
        }
        .container {
            max-width: 1000px;
            margin-top: 30px;
            margin-bottom: 30px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .form-control, .form-select {
            padding: 0.4rem 0.75rem;
            font-size: 0.9rem;
        }
        .table th, .table td {
            vertical-align: middle;
            font-size: 0.85rem; /* Smaller font for table */
        }
        .table-responsive {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h3 class="text-center mb-4">Tyre Product Management</h3>

    <div class="mb-3">
        <a href="search.php" class="btn btn-secondary">Back to Search</a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $alert_type ?> alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <?= htmlspecialchars($form_title) ?>
        </div>
        <div class="card-body">
            <form method="POST" action="<?= htmlspecialchars($form_action) ?>">
                <?php if (!empty($product_id)): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($product_id) ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label for="brand" class="form-label">Tyre Brand:</label>
                    <select class="form-select" id="brand" name="brand" required>
                        <option value="">Select Brand</option>
                        <option value="MRF" <?= ($brand === 'MRF') ? 'selected' : '' ?>>MRF</option>
                        <option value="APLLO" <?= ($brand === 'APLLO') ? 'selected' : '' ?>>APLLO</option>
                        <option value="JKT" <?= ($brand === 'JKT') ? 'selected' : '' ?>>JKT</option>
                        <option value="Ceat" <?= ($brand === 'Ceat') ? 'selected' : '' ?>>Ceat</option>
                        <option value="Firestone" <?= ($brand === 'Firestone') ? 'selected' : '' ?>>Firestone</option>
                        <option value="Goodyear" <?= ($brand === 'Goodyear') ? 'selected' : '' ?>>Goodyear</option>
                        <option value="Michelin" <?= ($brand === 'Michelin') ? 'selected' : '' ?>>Michelin</option>
                        <option value="Pirelli" <?= ($brand === 'Pirelli') ? 'selected' : '' ?>>Pirelli</option>
                        <option value="Continental" <?= ($brand === 'Continental') ? 'selected' : '' ?>>Continental</option>
                        <option value="Bridgestone" <?= ($brand === 'Bridgestone') ? 'selected' : '' ?>>Bridgestone</option>
                    </select>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="model" class="form-label">Model:</label>
                        <input type="text" class="form-control" id="model" name="model" value="<?= htmlspecialchars($model) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="size" class="form-label">Size:</label>
                        <input type="text" class="form-control" id="size" name="size" value="<?= htmlspecialchars($size) ?>" placeholder="e.g., 205/55R16">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="price" class="form-label">Price (₹):</label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= htmlspecialchars($price) ?>" required min="0">
                    </div>
                    <div class="col-md-6">
                        <label for="stock" class="form-label">Stock Quantity:</label>
                        <input type="number" class="form-control" id="stock" name="stock" value="<?= htmlspecialchars($stock) ?>" required min="0">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Tyre Type:</label>
                    <select class="form-select" id="type" name="type">
                        <option value="">Select Type (Optional)</option>
                        <option value="Radial" <?= ($type === 'Radial') ? 'selected' : '' ?>>Radial</option>
                        <option value="Tubeless" <?= ($type === 'Tubeless') ? 'selected' : '' ?>>Tubeless</option>
                        <option value="Bias" <?= ($type === 'Bias') ? 'selected' : '' ?>>Bias</option>
                        <option value="Run-Flat" <?= ($type === 'Run-Flat') ? 'selected' : '' ?>>Run-Flat</option>
                        <option value="All-Season" <?= ($type === 'All-Season') ? 'selected' : '' ?>>All-Season</option>
                        <option value="Summer" <?= ($type === 'Summer') ? 'selected' : '' ?>>Summer</option>
                        <option value="Winter" <?= ($type === 'Winter') ? 'selected' : '' ?>>Winter</option>
                        <option value="Performance" <?= ($type === 'Performance') ? 'selected' : '' ?>>Performance</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary"><?= htmlspecialchars($submit_button_text) ?></button>
                <?php if (!empty($product_id)): ?>
                    <a href="product_management.php" class="btn btn-secondary">Cancel Edit</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <h4 class="mt-5 mb-3">Existing Tyre Products</h4>
    <?php if (!empty($tyre_products)): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>Size</th>
                        <th>Price (₹)</th>
                        <th>Stock</th>
                        <th>Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tyre_products as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['id']) ?></td>
                            <td><?= htmlspecialchars($product['brand']) ?></td>
                            <td><?= htmlspecialchars($product['model']) ?></td>
                            <td><?= htmlspecialchars($product['size']) ?></td>
                            <td><?= number_format($product['price'], 2) ?></td>
                            <td><?= htmlspecialchars($product['stock']) ?></td>
                            <td><?= htmlspecialchars($product['type']) ?></td>
                            <td>
                                <a href="product_management.php?id=<?= urlencode($product['id']) ?>" class="btn btn-sm btn-info me-1">Edit</a>
                                <a href="delete_product.php?id=<?= urlencode($product['id']) ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Are you sure you want to delete <?= htmlspecialchars($product['brand'] . ' ' . $product['model']) ?>? This action cannot be undone.');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info" role="alert">
            No tyre products found. Add a new one using the form above!
        </div>
    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>