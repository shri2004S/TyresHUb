<?php
include 'dbconn.php'; // This connects to the 'tyres' database

// Initialize variables for form fields
$bill_number = '';
$billing_date = '';
$customer_name = '';
$contact_number = '';
$brand1 = '';
$model1 = '';
$qty1 = '';
$price1 = '';
$subtotal1 = '';
$brand2 = '';
$model2 = '';
$qty2 = '';
$price2 = '';
$subtotal2 = '';
$total_amount = '';
$payment_method = '';
$is_edit_mode = false;

// Check if we're in edit mode (bill_number parameter passed)
if (isset($_GET['bill_number']) && !empty($_GET['bill_number'])) {
    $edit_bill_number = $_GET['bill_number'];
    $is_edit_mode = true;

    // Fetch existing data from database
    $stmt = $conn->prepare("SELECT * FROM bill WHERE bill_number = ?");
    $stmt->bind_param("s", $edit_bill_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Populate form fields with existing data
        $bill_number = $row['bill_number'];
        $billing_date = $row['billing_date'];
        $customer_name = $row['customer_name'];
        $contact_number = $row['contact_number'];
        $brand1 = $row['brand1'];
        $model1 = $row['model1'];
        $qty1 = $row['qty1'];
        $price1 = $row['price1'];
        $subtotal1 = $row['subtotal1'];
        $brand2 = $row['brand2'];
        $model2 = $row['model2'];
        $qty2 = $row['qty2'];
        $price2 = $row['price2'];
        $subtotal2 = $row['subtotal2'];
        $total_amount = $row['total_amount'];
        $payment_method = $row['payment_method'];
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>The Perfect Tyres - Billing Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f4f4f4;
      font-size: 14px;
    }

    .form-label {
      font-weight: bold;
      margin-bottom: 5px;
    }

    .btn-custom {
      width: 100px;
    }

    .form-section {
      padding: 30px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    .logo-container {
      background-color: white;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 30px;
    }

    .logo-container img {
      max-width: 100%;
      height: auto;
      max-height: 250px;
    }

    .mb-2 {
      margin-bottom: 0.5rem !important;
    }

    .mb-3 {
      margin-bottom: 1rem !important;
    }

    .form-control, .form-select {
      padding: 0.4rem 0.75rem;
      font-size: 0.9rem;
    }

    /* Bill Print Format */
    .bill-format {
      display: none;
    }

    /* Print Styles - Only show bill format */
    @media print {
      body {
        background-color: white !important;
        font-size: 12px;
        margin: 0;
        padding: 0;
      }

      .container {
        display: none !important;
      }

      .bill-format {
        display: block !important;
        width: 100%;
        max-width: 100%;
        margin: 0;
        padding: 20px;
        font-family: Arial, sans-serif;
      }

      .bill-header {
        text-align: center;
        border-bottom: 2px solid #000;
        padding-bottom: 15px;
        margin-bottom: 20px;
      }

      .bill-header h2 {
        margin: 0;
        font-size: 24px;
        font-weight: bold;
      }

      .bill-header p {
        margin: 5px 0;
        font-size: 14px;
      }

      .bill-info {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
      }

      .bill-info div {
        flex: 1;
      }

      .bill-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
      }

      .bill-table th,
      .bill-table td {
        border: 1px solid #000;
        padding: 8px;
        text-align: left;
      }

      .bill-table th {
        background-color: #f0f0f0;
        font-weight: bold;
      }

      .bill-total {
        text-align: right;
        font-size: 16px;
        font-weight: bold;
        margin-top: 10px;
      }

      .bill-footer {
        margin-top: 30px;
        text-align: center;
        border-top: 1px solid #000;
        padding-top: 15px;
      }

      @page {
        size: A4;
        margin: 0.5in;
      }
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <div class="row g-0 shadow rounded-3 overflow-hidden">

    <div class="col-md-6 logo-container">
      <img src="img/tyres13.png" alt="The Perfect Tyres Logo" style="width: 500px; height: 1000px;" />
    </div>

    <div class="col-md-6 form-section">
      <h3 class="text-center mb-4">
        <?php echo $is_edit_mode ? 'Edit Invoice' : 'Billing Invoice'; ?>
      </h3>

      <?php if ($is_edit_mode): ?>
        <div class="alert alert-info">
          <strong>Edit Mode:</strong> You are editing bill number: <?php echo htmlspecialchars($bill_number); ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo $is_edit_mode ? 'update.php' : 'insert.php'; ?>" oninput="calculateTotal()">

        <?php if ($is_edit_mode): ?>
          <input type="hidden" name="is_edit" value="1">
          <input type="hidden" name="original_bill_number" value="<?php echo htmlspecialchars($bill_number); ?>">
        <?php endif; ?>

        <div class="row mb-3">
          <div class="col-6">
            <label for="billNo" class="form-label">Bill Number</label>
            <input type="text" id="billNo" class="form-control" placeholder="Enter Bill No" name="bill_number" value="<?php echo htmlspecialchars($bill_number); ?>">
          </div>
          <div class="col-6">
            <label for="date" class="form-label">Billing Date</label>
            <input type="date" id="date" class="form-control" name="billing_date" value="<?php echo htmlspecialchars($billing_date); ?>">
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-6">
            <label for="customerName" class="form-label">Customer Name</label>
            <input type="text" id="customerName" class="form-control" placeholder="Enter Customer Name" name="customer_name" value="<?php echo htmlspecialchars($customer_name); ?>">
          </div>
          <div class="col-6">
            <label for="contact" class="form-label">Contact Number</label>
            <input type="text" id="contact" class="form-control" placeholder="Enter Contact Number" name="contact_number" value="<?php echo htmlspecialchars($contact_number); ?>">
          </div>
        </div>

        <h5 class="mt-4">Tyre Items</h5>

        <div class="row mb-2">
          <div class="col-6">
            <label for="brand1" class="form-label visually-hidden">Brand 1</label>
            <select class="form-select brand-select" name="brand1" id="brand1">
              <option <?php echo empty($brand1) ? 'selected' : ''; ?> disabled>Select Brand</option>
              <option value="Apollo" <?php echo $brand1 === 'Apollo' ? 'selected' : ''; ?>>Apollo</option>
              <option value="MRF" <?php echo $brand1 === 'MRF' ? 'selected' : ''; ?>>MRF</option>
              <option value="Bridgestone" <?php echo $brand1 === 'Bridgestone' ? 'selected' : ''; ?>>Bridgestone</option>
              <option value="CEAT" <?php echo $brand1 === 'CEAT' ? 'selected' : ''; ?>>CEAT</option>
              <option value="Michelin" <?php echo $brand1 === 'Michelin' ? 'selected' : ''; ?>>Michelin</option>
            </select>
          </div>
          <div class="col-6">
            <label for="model1" class="form-label visually-hidden">Model 1</label>
            <select class="form-select model-select" name="model1" id="model1">
              <option <?php echo empty($model1) ? 'selected' : ''; ?> disabled>Select Model</option>
              <option value="Radial X" <?php echo $model1 === 'Radial X' ? 'selected' : ''; ?>>Radial X</option>
              <option value="GripPro" <?php echo $model1 === 'GripPro' ? 'selected' : ''; ?>>GripPro</option>
              <option value="ZoomDrive" <?php echo $model1 === 'ZoomDrive' ? 'selected' : ''; ?>>ZoomDrive</option>
              <option value="EcoRun" <?php echo $model1 === 'EcoRun' ? 'selected' : ''; ?>>EcoRun</option>
              <option value="UltraSport" <?php echo $model1 === 'UltraSport' ? 'selected' : ''; ?>>UltraSport</option>
            </select>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col-3">
            <label for="qty1" class="form-label visually-hidden">Quantity 1</label>
            <input type="number" name="qty1" id="qty1" class="form-control qty" placeholder="Qty" value="<?php echo htmlspecialchars($qty1); ?>">
          </div>
          <div class="col-3">
            <label for="price1" class="form-label visually-hidden">Price 1</label>
            <input type="number" name="price1" id="price1" class="form-control price" placeholder="Price" value="<?php echo htmlspecialchars($price1); ?>">
          </div>
          <div class="col-6">
            <label for="subtotal1" class="form-label visually-hidden">Subtotal 1</label>
            <input type="text" name="subtotal1" id="subtotal1" class="form-control subtotal" placeholder="Subtotal" readonly value="<?php echo htmlspecialchars($subtotal1); ?>">
          </div>
        </div>

        <div class="row mb-2">
          <div class="col-6">
            <label for="brand2" class="form-label visually-hidden">Brand 2</label>
            <select class="form-select brand-select" name="brand2" id="brand2">
              <option <?php echo empty($brand2) ? 'selected' : ''; ?> disabled>Select Brand</option>
              <option value="Apollo" <?php echo $brand2 === 'Apollo' ? 'selected' : ''; ?>>Apollo</option>
              <option value="MRF" <?php echo $brand2 === 'MRF' ? 'selected' : ''; ?>>MRF</option>
              <option value="Bridgestone" <?php echo $brand2 === 'Bridgestone' ? 'selected' : ''; ?>>Bridgestone</option>
              <option value="CEAT" <?php echo $brand2 === 'CEAT' ? 'selected' : ''; ?>>CEAT</option>
              <option value="Michelin" <?php echo $brand2 === 'Michelin' ? 'selected' : ''; ?>>Michelin</option>
            </select>
          </div>
          <div class="col-6">
            <label for="model2" class="form-label visually-hidden">Model 2</label>
            <select class="form-select model-select" name="model2" id="model2">
              <option <?php echo empty($model2) ? 'selected' : ''; ?> disabled>Select Model</option>
              <option value="Radial X" <?php echo $model2 === 'Radial X' ? 'selected' : ''; ?>>Radial X</option>
              <option value="GripPro" <?php echo $model2 === 'GripPro' ? 'selected' : ''; ?>>GripPro</option>
              <option value="ZoomDrive" <?php echo $model2 === 'ZoomDrive' ? 'selected' : ''; ?>>ZoomDrive</option>
              <option value="EcoRun" <?php echo $model2 === 'EcoRun' ? 'selected' : ''; ?>>EcoRun</option>
              <option value="UltraSport" <?php echo $model2 === 'UltraSport' ? 'selected' : ''; ?>>UltraSport</option>
            </select>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col-3">
            <label for="qty2" class="form-label visually-hidden">Quantity 2</label>
            <input type="number" name="qty2" id="qty2" class="form-control qty" placeholder="Qty" value="<?php echo htmlspecialchars($qty2); ?>">
          </div>
          <div class="col-3">
            <label for="price2" class="form-label visually-hidden">Price 2</label>
            <input type="number" class="form-control price" name="price2" id="price2" placeholder="Price" value="<?php echo htmlspecialchars($price2); ?>">
          </div>
          <div class="col-6">
            <label for="subtotal2" class="form-label visually-hidden">Subtotal 2</label>
            <input type="text" class="form-control subtotal" name="subtotal2" id="subtotal2" placeholder="Subtotal" readonly value="<?php echo htmlspecialchars($subtotal2); ?>">
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-6">
            <label for="total" class="form-label">Total Amount</label>
            <input type="text" id="total" name="total_amount" class="form-control" readonly value="<?php echo htmlspecialchars($total_amount); ?>">
          </div>
          <div class="col-6">
            <label for="payment" class="form-label">Payment Method</label>
            <select id="payment" class="form-select" name="payment_method">
              <option <?php echo empty($payment_method) ? 'selected' : ''; ?> disabled>Select Payment</option>
              <option value="Cash" <?php echo $payment_method === 'Cash' ? 'selected' : ''; ?>>Cash</option>
              <option value="Card" <?php echo $payment_method === 'Card' ? 'selected' : ''; ?>>Card</option>
              <option value="UPI" <?php echo $payment_method === 'UPI' ? 'selected' : ''; ?>>UPI</option>
              <option value="Bank Transfer" <?php echo $payment_method === 'Bank Transfer' ? 'selected' : ''; ?>>Bank Transfer</option>
            </select>
          </div>
        </div>

        <div class="d-flex justify-content-between">
          <button type="submit" class="btn btn-primary btn-custom">
            <?php echo $is_edit_mode ? 'Update Bill' : 'Generate Bill'; ?>
          </button>
          <button type="button" class="btn btn-success btn-custom" onclick="printBill()">Print Bill</button>
          <a href="index.php" class="btn btn-secondary btn-custom">Back</a>
        </div>

      </form>
    </div>
  </div>
</div>

<div class="bill-format">
  <div class="bill-header">
    <h2>THE PERFECT TYRES</h2>
    <p>Quality Tyres for Every Vehicle</p>
    <p>Contact: +91-8788697186 | Email: info@perfecttyres.com</p>
  </div>

  <div class="bill-info">
    <div>
      <strong>Bill No:</strong> <span id="print-billNo"></span><br>
      <strong>Date:</strong> <span id="print-date"></span>
    </div>
    <div>
      <strong>Customer:</strong> <span id="print-customerName"></span><br>
      <strong>Contact:</strong> <span id="print-contact"></span>
    </div>
  </div>

  <table class="bill-table">
    <thead>
      <tr>
        <th>Sr. No.</th>
        <th>Brand</th>
        <th>Model</th>
        <th>Qty</th>
        <th>Unit Price</th>
        <th>Amount</th>
      </tr>
    </thead>
    <tbody id="print-items"></tbody>
  </table>

  <div class="bill-total">
    <strong>Payment Method:</strong> <span id="print-payment"></span><br><br>
    <strong>TOTAL AMOUNT: ₹<span id="print-total"></span></strong>
  </div>

  <div class="bill-footer">
    <p>Thank you for your business!</p>
    <p>This is a computer-generated bill.</p>
  </div>
</div>

<script>
  function calculateTotal() {
    const qtyInputs = document.querySelectorAll(".qty");
    const priceInputs = document.querySelectorAll(".price");
    const subtotalInputs = document.querySelectorAll(".subtotal");
    let total = 0;

    for (let i = 0; i < qtyInputs.length; i++) {
      const qty = parseFloat(qtyInputs[i].value) || 0;
      const price = parseFloat(priceInputs[i].value) || 0;
      const subtotal = qty * price;
      subtotalInputs[i].value = subtotal > 0 ? subtotal.toFixed(2) : '';
      total += subtotal;
    }

    document.getElementById("total").value = total.toFixed(2);
  }

  function printBill() {
    document.getElementById("print-billNo").textContent = document.getElementById("billNo").value;
    document.getElementById("print-date").textContent = document.getElementById("date").value;
    document.getElementById("print-customerName").textContent = document.getElementById("customerName").value;
    document.getElementById("print-contact").textContent = document.getElementById("contact").value;
    document.getElementById("print-payment").textContent = document.getElementById("payment").value;
    document.getElementById("print-total").textContent = document.getElementById("total").value;

    const printItems = document.getElementById("print-items");
    printItems.innerHTML = "";

    const brandSelects = document.querySelectorAll(".brand-select");
    const modelSelects = document.querySelectorAll(".model-select");
    const qtyInputs = document.querySelectorAll(".qty");
    const priceInputs = document.querySelectorAll(".price");
    const subtotalInputs = document.querySelectorAll(".subtotal");

    for (let i = 0; i < brandSelects.length; i++) {
      // Only add rows for items that have a quantity and price entered
      if (qtyInputs[i].value && priceInputs[i].value && brandSelects[i].value !== 'Select Brand' && modelSelects[i].value !== 'Select Model') {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${i + 1}</td>
          <td>${brandSelects[i].value}</td>
          <td>${modelSelects[i].value}</td>
          <td>${qtyInputs[i].value}</td>
          <td>₹${parseFloat(priceInputs[i].value).toFixed(2)}</td>
          <td>₹${parseFloat(subtotalInputs[i].value).toFixed(2)}</td>
        `;
        printItems.appendChild(row);
      }
    }

    window.print();
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Set current date only if not in edit mode or if date is empty
    const dateInput = document.getElementById('date');
    if (!dateInput.value) {
      dateInput.value = new Date().toISOString().split('T')[0];
    }

    // Calculate total on page load (for edit mode to update subtotals/total if values loaded)
    calculateTotal();
  });
</script>

</body>
</html>