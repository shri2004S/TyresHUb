<?php
include 'dbconn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ThePerfectTyres</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'dbconn.php'; ?>

<header>
  <div class="container">
    <h1 class="logo">ThePerfectTyres</h1>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#products">Products</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="From.html">Buy</a></li>
        <li><a href="bill.php">Bill print</a></li>
      </ul>
    </nav>
  </div>
</header>

<section class="hero">
  <div class="slider-container">
    <div class="slider-card active">
      <h2>Best Tyres</h2>
      <p>Lightweight, durable</p>
    </div>
    <div class="slider-card">
      <h2>Affordable</h2>
      <p>Best Price Guaranteed</p>
    </div>
    <div class="slider-card">
      <h2>Safe Rides and Happy Rides</h2>
      <p>Drive with Confidence</p>
    </div>
    <button class="prev" onclick="prevSlide()">&#10094;</button>
    <button class="next" onclick="nextSlide()">&#10095;</button>
  </div>
</section>

<section id="products" class="products">
  <h2>Popular Products</h2>
  <div class="product-list">
    <div class="product-card">
      <img src="img/tyres1.jpg" alt="Tyre 1">
      <h3>Classic Tyres</h3>
      <p>&#8377;999</p>
    </div>
    <div class="product-card">
      <img src="img/tyres2.jpg" alt="Tyre 2">
      <h3>Speed Tyres</h3>
      <p>&#8377;1499</p>
    </div>
    <div class="product-card">
      <img src="img/tyres5.jpg" alt="Tyre 3">
      <h3>Pro Tyres</h3>
      <p>&#8377;1999</p>
    </div>
  </div>
</section>

<section class="brands-section">
  <h2 class="section-title">Brands We Deal In</h2>
  <p class="section-subtitle">Authentic Products From Trusted Sources</p>
  <div class="brand-divider"><img src="img/icons8.png" alt="divider"></div>
  <div class="brand-tabs">
    <a href="car.php"><button>SUV/CARS</button></a>
    <a href="Truck.php"><button>TRUCK/BUS</button></a>
    <a href="Bike.php"><button>BIKE/SCOOTER</button></a>
    <a href="otr.php"><button>OTR</button></a>
  </div>
  <div class="logo-row">
    <div class="logo-box">
      <img src="img/jkt.png.svg" alt="JK Tyre">
      <p>JK Tyre</p>
    </div>
    <div class="logo-box">
      <img src="img/apoll.png" alt="Apollo Tyre">
      <p>Apollo Tyre</p>
    </div>
  </div>
</section>

<section class="services-section">
  <h2 class="section-title">OUR INSTANT SERVICES</h2>
  <div class="services-grid">
    <div class="service-card"><img src="img/1.png" alt="Wheel Alignment"><h3>WHEEL ALIGNMENT</h3></div>
    <div class="service-card"><img src="img/2.png" alt="Tyre"><h3>TYRE FITTING</h3></div>
    <div class="service-card"><img src="img/3.png" alt="Suspension"><h3>SUSPENSION CHECK UP</h3></div>
    <div class="service-card"><img src="img/4.png" alt="Wheel Balancing"><h3>WHEEL BALANCING</h3></div>
    <div class="service-card"><img src="img/5.png" alt="Tyre Rotation"><h3>TYRE ROTATION</h3></div>
    <div class="service-card"><img src="img/6.png" alt="Nitrogen"><h3>NITROGEN INFLATION</h3></div>
    <div class="service-card"><img src="img/7.png" alt="AC Gas"><h3>CAR AC GAS REFILLING</h3></div>
    <div class="service-card"><img src="img/8.png" alt="Puncture Repair"><h3>TUBELESS PUNCTURE REPAIR</h3></div>
  </div>
</section>

<section id="about" class="about">
  <div class="container">
    <h2>About Us</h2>
    <p>We are one of the best tyre dealers in Nagpur, India. We are authorised tyre dealers of JK, Apollo, CEAT, Bridgestone and more. Your one-stop destination for tyres of all kinds—Bikes, Scooters, Cars, Trucks, Buses, Tractors, OTR, Mining and Industrial. MHKS Tyre Care offers exceptional service with skilled technicians for your safety.</p>
  </div>
</section>

<footer id="contact">
  <div class="container">
    <p>&copy; 2025 TyperBuy. All rights reserved.</p>
    <p>Contact: <a href="mailto:support@typerbuy.com">support@typerbuy.com</a></p>
  </div>
</footer>

<script>
let current = 0;
const cards = document.querySelectorAll('.slider-card');
function showSlide(index) {
  cards.forEach((card, i) => {
    card.classList.remove('active');
    if (i === index) card.classList.add('active');
  });
}
function nextSlide() {
  current = (current + 1) % cards.length;
  showSlide(current);
}
function prevSlide() {
  current = (current - 1 + cards.length) % cards.length;
  showSlide(current);
}
setInterval(nextSlide, 4000);
</script>

</body>
</html>
