<?php
include 'dbconn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Attendance System using QR Code</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            overflow: hidden;
        }

        .presentation-container {
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .slide {
            width: 90%;
            max-width: 1000px;
            height: 90%;
            max-height: 700px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
            display: none;
            overflow-y: auto;
            position: relative;
        }

        .slide.active {
            display: block;
            animation: slideIn 0.5s ease-in-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(30px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .slide h1 {
            color: #2c3e50;
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 3px solid #3498db;
            padding-bottom: 15px;
        }

        .slide h2 {
            color: #34495e;
            font-size: 2em;
            margin-bottom: 15px;
            border-left: 5px solid #3498db;
            padding-left: 20px;
        }

        .slide h3 {
            color: #2980b9;
            font-size: 1.5em;
            margin-bottom: 10px;
        }

        .slide p, .slide li {
            color: #555;
            line-height: 1.8;
            font-size: 1.1em;
            margin-bottom: 10px;
        }

        .slide ul {
            margin-left: 20px;
            margin-bottom: 20px;
        }

        .slide li {
            margin-bottom: 8px;
        }

        .team-info {
            background: linear-gradient(45deg, #f39c12, #e74c3c);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }

        .tech-stack {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }

        .tech-item {
            background: linear-gradient(45deg, #3498db, #2980b9);
            color: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .qr-demo {
            width: 200px;
            height: 200px;
            background: #ecf0f1;
            border: 2px dashed #3498db;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 20px auto;
            font-size: 1.2em;
            color: #7f8c8d;
        }

        .navigation {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
        }

        .nav-btn {
            padding: 10px 20px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background 0.3s;
        }

        .nav-btn:hover {
            background: #2980b9;
        }

        .nav-btn:disabled {
            background: #bdc3c7;
            cursor: not-allowed;
        }

        .slide-counter {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(52, 152, 219, 0.1);
            padding: 5px 15px;
            border-radius: 20px;
            color: #2980b9;
            font-weight: bold;
        }

        .highlight-box {
            background: linear-gradient(45deg, #ff9a9e, #fecfef);
            padding: 20px;
            border-radius: 10px;
            margin: 15px 0;
            border-left: 5px solid #e91e63;
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .benefit-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #28a745;
            text-align: center;
        }

        .methodology-flow {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            flex-wrap: wrap;
            gap: 10px;
        }

        .flow-item {
            background: linear-gradient(45deg, #6c5ce7, #a29bfe);
            color: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            flex: 1;
            min-width: 150px;
        }

        .arrow {
            font-size: 2em;
            color: #3498db;
        }
    </style>
</head>
<body>
    <div class="presentation-container">
        <!-- Slide 1: Title Slide -->
        <div class="slide active">
            <div class="slide-counter">1 / 10</div>
            <h1>Smart Attendance System</h1>
            <h2 style="text-align: center; color: #3498db;">Using QR Code Punch-In and Punch-Out</h2>
            
            <div class="qr-demo">
                📱 QR Code Demo
            </div>

            <div class="team-info">
                <h3 style="color: white; text-align: center;">Project Team</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
                    <div>
                        <p><strong>Harsh Bhidekar</strong><br>Roll No: 66<br>MCA Final Year</p>
                    </div>
                    <div>
                        <p><strong>Shriniwas Dubbewar</strong><br>Roll No: 78<br>MCA Final Year</p>
                    </div>
                </div>
                <p style="text-align: center; margin-top: 15px;"><strong>Master Of Computer Application</strong></p>
            </div>
        </div>

        <!-- Slide 2: Problem Statement -->
        <div class="slide">
            <div class="slide-counter">2 / 10</div>
            <h1>Problem Statement</h1>
            
            <div class="highlight-box">
                <h3>Current Challenges in Attendance Management</h3>
            </div>

            <ul style="font-size: 1.2em; line-height: 2;">
                <li><strong>Time-Consuming Manual Process:</strong> Traditional paper-based attendance takes valuable class/work time</li>
                <li><strong>Error-Prone System:</strong> Human errors in recording and calculating attendance</li>
                <li><strong>Proxy Attendance:</strong> Easy to manipulate with friends marking attendance for absent individuals</li>
                <li><strong>Real-Time Tracking Issues:</strong> Difficulty in accessing live attendance data</li>
                <li><strong>Data Management Problems:</strong> Physical registers are hard to maintain and can be lost</li>
                <li><strong>Report Generation Complexity:</strong> Manual compilation of attendance reports is tedious</li>
            </ul>

            <div style="background: #ffe6e6; padding: 15px; border-radius: 8px; margin-top: 20px; text-align: center;">
                <p style="color: #d63384; font-weight: bold; font-size: 1.2em;">
                    💡 Solution Needed: A digital, automated, and secure attendance system
                </p>
            </div>
        </div>

        <!-- Slide 3: Objectives -->
        <div class="slide">
            <div class="slide-counter">3 / 10</div>
            <h1>Project Objectives</h1>

            <div class="benefits-grid">
                <div class="benefit-item">
                    <h3 style="color: #2980b9;">🎯 Quick Check-in</h3>
                    <p>Design QR code-based system for instant attendance marking</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #2980b9;">📊 Real-time Dashboard</h3>
                    <p>Web-based admin panel for live attendance monitoring</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #2980b9;">📈 Automated Reports</h3>
                    <p>Generate daily, weekly, and monthly attendance reports</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #2980b9;">👥 User-Friendly Interface</h3>
                    <p>Simple interface for students, employees, and administrators</p>
                </div>
            </div>

            <div class="highlight-box">
                <h3>Additional Unique Objectives</h3>
                <ul>
                    <li><strong>Geo-location Verification:</strong> Ensure attendance is marked from designated locations</li>
                    <li><strong>Multi-platform Support:</strong> Works on smartphones, tablets, and computers</li>
                    <li><strong>Data Analytics:</strong> Provide insights on attendance patterns and trends</li>
                    <li><strong>Notification System:</strong> Alert parents/supervisors about attendance status</li>
                </ul>
            </div>
        </div>

        <!-- Slide 4: System Architecture -->
        <div class="slide">
            <div class="slide-counter">4 / 10</div>
            <h1>System Architecture</h1>

            <div class="methodology-flow">
                <div class="flow-item">
                    <h3>📱 Scanning Module</h3>
                    <p>Web app with camera integration for QR scanning</p>
                </div>
                <div class="arrow">→</div>
                <div class="flow-item">
                    <h3>🗄️ Database Layer</h3>
                    <p>Secure storage of user data and timestamps</p>
                </div>
                <div class="arrow">→</div>
                <div class="flow-item">
                    <h3>⚡ Processing Logic</h3>
                    <p>Punch-in/out detection and duration calculation</p>
                </div>
                <div class="arrow">→</div>
                <div class="flow-item">
                    <h3>📊 Admin Dashboard</h3>
                    <p>Real-time monitoring and report generation</p>
                </div>
            </div>

            <div class="highlight-box">
                <h3>Unique System Features</h3>
                <ul>
                    <li><strong>Smart Duplicate Detection:</strong> Prevents multiple scans within short intervals</li>
                    <li><strong>Offline Capability:</strong> Store data locally when internet is unavailable</li>
                    <li><strong>Multi-QR Support:</strong> Different QR codes for different locations/events</li>
                    <li><strong>Biometric Integration:</strong> Optional fingerprint verification for enhanced security</li>
                </ul>
            </div>
        </div>

        <!-- Slide 5: Technology Stack -->
        <div class="slide">
            <div class="slide-counter">5 / 10</div>
            <h1>Technology Stack</h1>

            <div class="tech-stack">
                <div class="tech-item" style="background: linear-gradient(45deg, #2c3e50, #34495e); color: white;">
                    <h3 style="color: #ecf0f1;">Backend Development</h3>
                    <p style="color: #bdc3c7;"><strong style="color: white;">Java, Spring, Spring Boot</strong><br>Robust server-side development</p>
                </div>
                <div class="tech-item" style="background: linear-gradient(45deg, #27ae60, #2ecc71); color: white;">
                    <h3 style="color: #ecf0f1;">Database Management</h3>
                    <p style="color: #d5f4e6;"><strong style="color: white;">MySQL, Firebase</strong><br>Reliable data storage and real-time sync</p>
                </div>
                <div class="tech-item" style="background: linear-gradient(45deg, #8e44ad, #9b59b6); color: white;">
                    <h3 style="color: #ecf0f1;">Frontend Development</h3>
                    <p style="color: #e8d5f0;"><strong style="color: white;">HTML5, CSS3, JavaScript</strong><br>Interactive user interfaces</p>
                </div>
                <div class="tech-item" style="background: linear-gradient(45deg, #e74c3c, #c0392b); color: white;">
                    <h3 style="color: #ecf0f1;">UI Framework</h3>
                    <p style="color: #fadbd8;"><strong style="color: white;">Bootstrap 5</strong><br>Responsive and modern design</p>
                </div>
            </div>

            <div class="highlight-box">
                <h3>Additional Technologies (Unique Additions)</h3>
                <ul>
                    <li><strong>QR Code Libraries:</strong> QRious.js for generation, jsQR for scanning</li>
                    <li><strong>Charts & Analytics:</strong> Chart.js for data visualization</li>
                    <li><strong>Push Notifications:</strong> Firebase Cloud Messaging (FCM)</li>
                    <li><strong>Security:</strong> JWT tokens for authentication, bcrypt for password hashing</li>
                    <li><strong>Camera API:</strong> WebRTC for real-time camera access</li>
                </ul>
            </div>
        </div>

        <!-- Slide 6: How It Works -->
        <div class="slide">
            <div class="slide-counter">6 / 10</div>
            <h1>How The System Works</h1>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin: 20px 0;">
                <div>
                    <h3 style="color: #27ae60;">📲 For Students/Employees:</h3>
                    <ol style="font-size: 1.1em; line-height: 1.8;">
                        <li>Open the web application</li>
                        <li>Allow camera access</li>
                        <li>Scan the QR code displayed at entry/exit</li>
                        <li>System records punch-in/punch-out automatically</li>
                        <li>Receive instant confirmation notification</li>
                    </ol>
                </div>
                <div>
                    <h3 style="color: #8e44ad;">👨‍💼 For Administrators:</h3>
                    <ol style="font-size: 1.1em; line-height: 1.8;">
                        <li>Access admin dashboard</li>
                        <li>Generate unique QR codes for locations</li>
                        <li>Monitor real-time attendance</li>
                        <li>Generate various reports</li>
                        <li>Manage user accounts and permissions</li>
                    </ol>
                </div>
            </div>

            <div class="highlight-box">
                <h3>🔄 Smart Logic Flow</h3>
                <p><strong>First Scan:</strong> Recorded as Punch-In with timestamp<br>
                <strong>Second Scan:</strong> Recorded as Punch-Out with duration calculation<br>
                <strong>Multiple Locations:</strong> Different QR codes track movement between areas</p>
            </div>
        </div>

        <!-- Slide 7: Key Features & Benefits -->
        <div class="slide">
            <div class="slide-counter">7 / 10</div>
            <h1>Key Features & Benefits</h1>

            <div class="benefits-grid">
                <div class="benefit-item">
                    <h3 style="color: #e74c3c;">⚡ Speed</h3>
                    <p>3-second attendance marking vs 5+ minutes traditional method</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #3498db;">🔒 Security</h3>
                    <p>Prevents proxy attendance with unique QR codes</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #27ae60;">💰 Cost-Effective</h3>
                    <p>No paper, no hardware investment needed</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #f39c12;">📊 Analytics</h3>
                    <p>Detailed insights and attendance patterns</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #9b59b6;">🌍 Accessible</h3>
                    <p>Works on any device with camera and internet</p>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #1abc9c;">🔄 Real-time</h3>
                    <p>Instant updates and notifications</p>
                </div>
            </div>

            <div class="highlight-box">
                <h3>Unique Advantages</h3>
                <ul>
                    <li><strong>Contactless Operation:</strong> No physical contact required - perfect for post-pandemic needs</li>
                    <li><strong>Environmental Friendly:</strong> Completely paperless solution</li>
                    <li><strong>Scalable:</strong> Can handle thousands of users simultaneously</li>
                    <li><strong>Integration Ready:</strong> Easy to integrate with existing systems</li>
                </ul>
            </div>
        </div>

        <!-- Slide 8: Expected Outcomes -->
        <div class="slide">
            <div class="slide-counter">8 / 10</div>
            <h1>Expected Outcomes</h1>

            <div class="highlight-box">
                <h3>📋 Project Deliverables</h3>
            </div>

            <ul style="font-size: 1.2em; line-height: 2;">
                <li><strong>✅ Functional Web Application:</strong> Complete QR code-based attendance system</li>
                <li><strong>📊 Administrative Dashboard:</strong> Centralized control panel for monitoring</li>
                <li><strong>📈 Significant Efficiency Gains:</strong> 95% reduction in manual effort</li>
                <li><strong>🎯 Error Reduction:</strong> 99% accuracy in attendance tracking</li>
            </ul>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 30px 0;">
                <div class="benefit-item">
                    <h3 style="color: #2980b9;">📊 Quantifiable Results</h3>
                    <ul>
                        <li>Time saved: 80% per session</li>
                        <li>Error reduction: 99%</li>
                        <li>Cost savings: 70% annually</li>
                        <li>User satisfaction: 95%+</li>
                    </ul>
                </div>
                <div class="benefit-item">
                    <h3 style="color: #27ae60;">🎯 Additional Outcomes</h3>
                    <ul>
                        <li>Improved data security</li>
                        <li>Better decision making</li>
                        <li>Enhanced user experience</li>
                        <li>Future-ready system</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Slide 9: Implementation Timeline -->
        <div class="slide">
            <div class="slide-counter">9 / 10</div>
            <h1>Implementation Timeline</h1>

            <div style="margin: 20px 0;">
                <div style="background: linear-gradient(90deg, #3498db, #2980b9); color: white; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h3>Phase 1: Planning & Design (2 weeks)</h3>
                    <p>Requirements analysis, UI/UX design, database schema design</p>
                </div>
                
                <div style="background: linear-gradient(90deg, #27ae60, #229954); color: white; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h3>Phase 2: Backend Development (3 weeks)</h3>
                    <p>API development, database setup, authentication system</p>
                </div>
                
                <div style="background: linear-gradient(90deg, #f39c12, #e67e22); color: white; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h3>Phase 3: Frontend Development (3 weeks)</h3>
                    <p>User interface, QR scanner integration, responsive design</p>
                </div>
                
                <div style="background: linear-gradient(90deg, #9b59b6, #8e44ad); color: white; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h3>Phase 4: Testing & Deployment (2 weeks)</h3>
                    <p>Unit testing, integration testing, user acceptance testing, deployment</p>
                </div>
            </div>

            <div class="highlight-box">
                <p style="text-align: center; font-size: 1.3em; font-weight: bold;">
                    🚀 Total Project Duration: 10 weeks
                </p>
            </div>
        </div>

        <!-- Slide 10: Thank You -->
        <div class="slide">
            <div class="slide-counter">10 / 10</div>
            <h1 style="text-align: center; color: #2c3e50;">Thank You!</h1>
            
            <div style="text-align: center; margin: 50px 0;">
                <div class="qr-demo" style="margin: 30px auto;">
                    🎓 Smart Attendance<br>System
                </div>
                
                <h2 style="color: #3498db; margin-bottom: 30px;">Questions & Discussion</h2>
                
                <div class="team-info">
                    <h3 style="color: white; text-align: center;">Contact Information</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                        <div>
                            <p><strong>Harsh Bhidekar</strong><br>📧 harsh.bhidekar@email.com<br>📱 +91-9876543210</p>
                        </div>
                        <div>
                            <p><strong>Shriniwas Dubbewar</strong><br>📧 shriniwas.dubbewar@email.com<br>📱 +91-9876543211</p>
                        </div>
                    </div>
                </div>
                
                <p style="margin-top: 30px; font-size: 1.2em; color: #555;">
                    <em>"Revolutionizing attendance management through innovation and technology"</em>
                </p>
            </div>
        </div>

        <!-- Navigation -->
        <div class="navigation">
            <button class="nav-btn" onclick="previousSlide()" id="prevBtn">◀ Previous</button>
            <span style="color: white; font-weight: bold; padding: 0 20px;" id="slideInfo">1 / 10</span>
            <button class="nav-btn" onclick="nextSlide()" id="nextBtn">Next ▶</button>
        </div>
    </div>

    <script>
        let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const totalSlides = slides.length;

        function showSlide(n) {
            slides[currentSlide].classList.remove('active');
            currentSlide = n;
            
            if (currentSlide >= totalSlides) currentSlide = 0;
            if (currentSlide < 0) currentSlide = totalSlides - 1;
            
            slides[currentSlide].classList.add('active');
            
            // Update navigation
            document.getElementById('prevBtn').disabled = currentSlide === 0;
            document.getElementById('nextBtn').disabled = currentSlide === totalSlides - 1;
            document.getElementById('slideInfo').textContent = `${currentSlide + 1} / ${totalSlides}`;
        }

        function nextSlide() {
            if (currentSlide < totalSlides - 1) {
                showSlide(currentSlide + 1);
            }
        }

        function previousSlide() {
            if (currentSlide > 0) {
                showSlide(currentSlide - 1);
            }
        }

        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowRight' || e.key === ' ') {
                nextSlide();
            } else if (e.key === 'ArrowLeft') {
                previousSlide();
            }
        });

        // Initialize
        showSlide(0);
    </script>
</body>
</html>