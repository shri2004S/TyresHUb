<?php
include 'dbconn.php';

$edit_mode = false;
$bill = [];



if (isset($_GET['bill_number'])) {
    $edit_mode = true;
    $bill_number = $_GET['bill_number'];

    $stmt = $conn->prepare("SELECT * FROM bill WHERE bill_number = ?");
    $stmt->bind_param("s", $bill_number);
    $stmt->execute();
    $result = $stmt->get_result();
    $bill = $result->fetch_assoc();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Billing Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="card">
    <div class="card-header">
      <h4><?= $edit_mode ? 'Edit Billing' : 'New Billing' ?></h4>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= $edit_mode ? 'update.php' : 'insert.php' ?>">
        <div class="mb-3">
          <label>Bill Number</label>
          <input type="text" name="bill_number" class="form-control" value="<?= $edit_mode ? htmlspecialchars($bill['bill_number']) : '' ?>" <?= $edit_mode ? 'readonly' : 'bill.php' ?> required>
        </div>
        <div class="mb-3">
          <label>Billing Date</label>
          <input type="date" name="billing_date" class="form-control" value="<?= $edit_mode ? $bill['billing_date'] : '' ?>" required>
        </div>
        <div class="mb-3">
          <label>Customer Name</label>
          <input type="text" name="customer_name" class="form-control" value="<?= $edit_mode ? htmlspecialchars($bill['customer_name']) : '' ?>" required>
        </div>
        <div class="mb-3">
          <label>Contact Number</label>
          <input type="text" name="contact_number" class="form-control" value="<?= $edit_mode ? htmlspecialchars($bill['contact_number']) : '' ?>" required>
        </div>
        <div class="mb-3">
          <label>Total Amount</label>
          <input type="number" step="0.01" name="total_amount" class="form-control" value="<?= $edit_mode ? $bill['total_amount'] : '' ?>" required>
        </div>
        <div class="mb-3">
          <label>Payment Method</label>
          <select name="payment_method" class="form-select" required>
            <option disabled <?= !$edit_mode ? 'selected' : '' ?>>Select Payment</option>
            <option <?= ($edit_mode && $bill['payment_method'] == 'Cash') ? 'selected' : '' ?>>Cash</option>
            <option <?= ($edit_mode && $bill['payment_method'] == 'Card') ? 'selected' : '' ?>>Card</option>
            <option <?= ($edit_mode && $bill['payment_method'] == 'UPI') ? 'selected' : '' ?>>UPI</option>
            <option <?= ($edit_mode && $bill['payment_method'] == 'Bank Transfer') ? 'selected' : '' ?>>Bank Transfer</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="fetch.php" class="btn btn-secondary">Cancel</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
