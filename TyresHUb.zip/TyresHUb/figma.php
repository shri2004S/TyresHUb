<?php
include 'dbconn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tyre Shop Admin Dashboard</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Inter font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6; /* Light gray background */
        }
        /* Custom scrollbar for better aesthetics */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #e0e0e0;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .dashboard-section {
            display: none; /* Hidden by default */
        }
        .dashboard-section.active {
            display: block; /* Show active section */
        }
        .sidebar-link.active {
            background-color: #4a5568; /* Darker gray for active link */
            color: #ffffff;
        }
        /* Basic styling for tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background-color: #edf2f7;
            font-weight: 600;
            color: #4a5568;
        }
        /* Modal styling */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            width: 90%;
            max-width: 500px;
            position: relative;
        }
        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
            cursor: pointer;
        }
        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body class="flex min-h-screen">

    <!-- Login Screen -->
    <div id="login-screen" class="flex items-center justify-center w-full min-h-screen bg-gray-100">
        <div class="bg-white p-8 rounded-lg shadow-xl w-96">
            <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Tyre Shop Admin</h2>
            <form id="login-form">
                <div class="mb-4">
                    <label for="username" class="block text-gray-700 text-sm font-medium mb-2">Username</label>
                    <input type="text" id="username" name="username" class="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200" placeholder="admin" required>
                </div>
                <div class="mb-6">
                    <label for="password" class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                    <input type="password" id="password" name="password" class="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200" placeholder="password" required>
                </div>
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200 shadow-md">
                    Login
                </button>
            </form>
            <p id="login-message" class="text-red-500 text-sm text-center mt-4 hidden"></p>
        </div>
    </div>

    <!-- Dashboard Layout -->
    <div id="dashboard-layout" class="hidden flex flex-1">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-800 text-white flex flex-col rounded-r-lg shadow-lg">
            <div class="p-6 text-2xl font-bold text-center border-b border-gray-700">
                Tyre Shop Admin
            </div>
            <nav class="flex-1 p-4">
                <ul class="space-y-2">
                    <li>
                        <a href="#" data-section="dashboard-overview" class="sidebar-link active block py-3 px-4 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition duration-200">Dashboard</a>
                    </li>
                    <li>
                        <a href="#" data-section="tyre-product-management" class="sidebar-link block py-3 px-4 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition duration-200">Tyre Products</a>
                    </li>
                    <li>
                        <a href="#" data-section="stock-management" class="sidebar-link block py-3 px-4 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition duration-200">Stock Management</a>
                    </li>
                    <li>
                        <a href="#" data-section="billing-system" class="sidebar-link block py-3 px-4 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition duration-200">Billing System</a>
                    </li>
                    <li>
                        <a href="#" data-section="reports-sales-history" class="sidebar-link block py-3 px-4 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition duration-200">Reports</a>
                    </li>
                    <li>
                        <a href="#" id="logout-button" class="block py-3 px-4 rounded-md text-gray-300 hover:bg-red-700 hover:text-white transition duration-200">Logout</a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8 overflow-y-auto">
            <div class="bg-white p-8 rounded-lg shadow-lg min-h-full">
                <!-- Dashboard Overview Section -->
                <section id="dashboard-overview" class="dashboard-section active">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Dashboard Overview</h1>
                    <p class="text-gray-600 mb-8">Welcome to the Tyre Shop Admin Panel. Use the sidebar to navigate through different sections.</p>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div class="bg-blue-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-blue-800">Total Products</h3>
                                <p class="text-3xl font-bold text-blue-900 mt-2">150</p>
                            </div>
                            <svg class="w-12 h-12 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        </div>
                        <div class="bg-green-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-green-800">Tyres in Stock</h3>
                                <p class="text-3xl font-bold text-green-900 mt-2">850</p>
                            </div>
                            <svg class="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
                        </div>
                        <div class="bg-yellow-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-yellow-800">Today's Sales</h3>
                                <p class="text-3xl font-bold text-yellow-900 mt-2">₹ 15,000</p>
                            </div>
                            <svg class="w-12 h-12 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V6m0 6v2m0 6v2"></path></svg>
                        </div>
                    </div>

                    <div class="mt-10">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <button class="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200" onclick="showSection('tyre-product-management')">Add New Tyre</button>
                            <button class="bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200" onclick="showSection('stock-management')">Update Stock</button>
                            <button class="bg-purple-500 hover:bg-purple-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200" onclick="showSection('billing-system')">Generate Bill</button>
                        </div>
                    </div>
                </section>

                <!-- Tyre Product Management Section -->
                <section id="tyre-product-management" class="dashboard-section">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Tyre Product Management</h1>
                    <p class="text-gray-600 mb-8">Manage your tyre brands and models here. You can add, update, or delete products.</p>

                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Add New Tyre</h2>
                        <form id="add-tyre-form" class="bg-gray-50 p-6 rounded-lg shadow-inner">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label for="tyre-name" class="block text-gray-700 text-sm font-medium mb-2">Tyre Name/Model</label>
                                    <input type="text" id="tyre-name" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Michelin Primacy 4" required>
                                </div>
                                <div>
                                    <label for="tyre-size" class="block text-gray-700 text-sm font-medium mb-2">Size</label>
                                    <input type="text" id="tyre-size" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="205/55R16" required>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                                <div>
                                    <label for="tyre-price" class="block text-gray-700 text-sm font-medium mb-2">Price (₹)</label>
                                    <input type="number" id="tyre-price" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="5500" step="0.01" required>
                                </div>
                                <div>
                                    <label for="tyre-stock" class="block text-gray-700 text-sm font-medium mb-2">Stock</label>
                                    <input type="number" id="tyre-stock" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="50" required>
                                </div>
                                <div>
                                    <label for="tyre-type" class="block text-gray-700 text-sm font-medium mb-2">Type</label>
                                    <select id="tyre-type" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                        <option value="">Select Type</option>
                                        <option value="Passenger">Passenger</option>
                                        <option value="Commercial">Commercial</option>
                                        <option value="Off-Road">Off-Road</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200">Add Tyre</button>
                        </form>
                    </div>

                    <div>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Existing Tyres</h2>
                        <div class="overflow-x-auto rounded-lg shadow-md">
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Name/Model</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Size</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Price</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Stock</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Type</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tyre-list">
                                    <!-- Example data -->
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">Goodyear Assurance</td>
                                        <td class="py-3 px-4">195/65R15</td>
                                        <td class="py-3 px-4">₹ 4200.00</td>
                                        <td class="py-3 px-4">75</td>
                                        <td class="py-3 px-4">Passenger</td>
                                        <td class="py-3 px-4">
                                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="editTyre(this)">Edit</button>
                                            <button class="text-red-600 hover:text-red-800 font-medium" onclick="deleteTyre(this)">Delete</button>
                                        </td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">MRF ZVTS</td>
                                        <td class="py-3 px-4">175/70R13</td>
                                        <td class="py-3 px-4">₹ 3100.00</td>
                                        <td class="py-3 px-4">120</td>
                                        <td class="py-3 px-4">Passenger</td>
                                        <td class="py-3 px-4">
                                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="editTyre(this)">Edit</button>
                                            <button class="text-red-600 hover:text-red-800 font-medium" onclick="deleteTyre(this)">Delete</button>
                                        </td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">Apollo Alnac 4G</td>
                                        <td class="py-3 px-4">215/60R17</td>
                                        <td class="py-3 px-4">₹ 6800.00</td>
                                        <td class="py-3 px-4">40</td>
                                        <td class="py-3 px-4">Passenger</td>
                                        <td class="py-3 px-4">
                                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="editTyre(this)">Edit</button>
                                            <button class="text-red-600 hover:text-red-800 font-medium" onclick="deleteTyre(this)">Delete</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- Stock Management Section -->
                <section id="stock-management" class="dashboard-section">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Stock Management</h1>
                    <p class="text-gray-600 mb-8">View and update the current stock levels of your tyres.</p>

                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Update Stock</h2>
                        <form id="update-stock-form" class="bg-gray-50 p-6 rounded-lg shadow-inner">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label for="stock-tyre-select" class="block text-gray-700 text-sm font-medium mb-2">Select Tyre</label>
                                    <select id="stock-tyre-select" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                        <option value="">-- Select a Tyre --</option>
                                        <option value="Goodyear Assurance">Goodyear Assurance (195/65R15)</option>
                                        <option value="MRF ZVTS">MRF ZVTS (175/70R13)</option>
                                        <option value="Apollo Alnac 4G">Apollo Alnac 4G (215/60R17)</option>
                                        <!-- More options would be dynamically loaded -->
                                    </select>
                                </div>
                                <div>
                                    <label for="stock-quantity" class="block text-gray-700 text-sm font-medium mb-2">Quantity Change</label>
                                    <input type="number" id="stock-quantity" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., 10 for add, -5 for sell" required>
                                </div>
                            </div>
                            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200">Update Stock</button>
                        </form>
                    </div>

                    <div>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Current Stock Levels</h2>
                        <div class="overflow-x-auto rounded-lg shadow-md">
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Tyre Name/Model</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Size</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Current Stock</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="current-stock-list">
                                    <!-- Example data -->
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">Goodyear Assurance</td>
                                        <td class="py-3 px-4">195/65R15</td>
                                        <td class="py-3 px-4">75</td>
                                        <td class="py-3 px-4"><span class="px-2 py-1 text-xs font-semibold leading-tight text-green-700 bg-green-100 rounded-full">In Stock</span></td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">MRF ZVTS</td>
                                        <td class="py-3 px-4">175/70R13</td>
                                        <td class="py-3 px-4">120</td>
                                        <td class="py-3 px-4"><span class="px-2 py-1 text-xs font-semibold leading-tight text-green-700 bg-green-100 rounded-full">In Stock</span></td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">Apollo Alnac 4G</td>
                                        <td class="py-3 px-4">40</td>
                                        <td class="py-3 px-4">40</td>
                                        <td class="py-3 px-4"><span class="px-2 py-1 text-xs font-semibold leading-tight text-orange-700 bg-orange-100 rounded-full">Low Stock</span></td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">Ceat Milaze</td>
                                        <td class="py-3 px-4">145/80R12</td>
                                        <td class="py-3 px-4">10</td>
                                        <td class="py-3 px-4"><span class="px-2 py-1 text-xs font-semibold leading-tight text-red-700 bg-red-100 rounded-full">Very Low</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- Billing System Section -->
                <section id="billing-system" class="dashboard-section">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Billing System</h1>
                    <p class="text-gray-600 mb-8">Generate bills for walk-in customers and view past records.</p>

                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Generate New Bill</h2>
                        <form id="generate-bill-form" class="bg-gray-50 p-6 rounded-lg shadow-inner">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label for="customer-name" class="block text-gray-700 text-sm font-medium mb-2">Customer Name (Optional)</label>
                                    <input type="text" id="customer-name" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="John Doe">
                                </div>
                                <div>
                                    <label for="customer-mobile" class="block text-gray-700 text-sm font-medium mb-2">Customer Mobile (Optional)</label>
                                    <input type="tel" id="customer-mobile" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="9876543210">
                                </div>
                            </div>

                            <div id="bill-items-container" class="mb-4 space-y-4">
                                <div class="bill-item grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                                    <div>
                                        <label for="bill-tyre-1" class="block text-gray-700 text-sm font-medium mb-2">Tyre</label>
                                        <select id="bill-tyre-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-tyre-select" data-item-id="1" required>
                                            <option value="">-- Select Tyre --</option>
                                            <option value="Goodyear Assurance" data-price="4200">Goodyear Assurance (₹ 4200)</option>
                                            <option value="MRF ZVTS" data-price="3100">MRF ZVTS (₹ 3100)</option>
                                            <option value="Apollo Alnac 4G" data-price="6800">Apollo Alnac 4G (₹ 6800)</option>
                                            <option value="Ceat Milaze" data-price="2800">Ceat Milaze (₹ 2800)</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="bill-quantity-1" class="block text-gray-700 text-sm font-medium mb-2">Quantity</label>
                                        <input type="number" id="bill-quantity-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-quantity-input" data-item-id="1" value="1" min="1" required>
                                    </div>
                                    <div>
                                        <label for="bill-price-1" class="block text-gray-700 text-sm font-medium mb-2">Price/Unit</label>
                                        <input type="text" id="bill-price-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight bg-gray-200 cursor-not-allowed" readonly value="0.00">
                                    </div>
                                    <div class="flex items-center">
                                        <button type="button" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200 remove-bill-item-btn">Remove</button>
                                    </div>
                                </div>
                            </div>
                            <button type="button" id="add-bill-item" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md shadow-md transition duration-200 mb-6">Add Another Item</button>

                            <div class="text-right text-xl font-bold text-gray-800 mb-6">
                                Total: <span id="bill-total">₹ 0.00</span>
                            </div>

                            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200">Generate Bill</button>
                        </form>
                    </div>

                    <div>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Bill Records</h2>
                        <div class="flex flex-col md:flex-row gap-4 mb-4">
                            <input type="text" id="search-bill-number" placeholder="Search by Bill No." class="shadow-sm appearance-none border rounded-md py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 flex-1">
                            <input type="date" id="search-bill-date" class="shadow-sm appearance-none border rounded-md py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <input type="text" id="search-bill-customer" placeholder="Search by Customer Name" class="shadow-sm appearance-none border rounded-md py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 flex-1">
                            <button class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200" onclick="searchBills()">Search</button>
                        </div>
                        <div class="overflow-x-auto rounded-lg shadow-md">
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Bill No.</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Date</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Customer Name</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Total Amount</th>
                                        <th class="py-3 px-4 uppercase font-semibold text-sm text-gray-600">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="bill-records-list">
                                    <!-- Example data -->
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">#2025001</td>
                                        <td class="py-3 px-4">2025-07-10</td>
                                        <td class="py-3 px-4">Alice Smith</td>
                                        <td class="py-3 px-4">₹ 8400.00</td>
                                        <td class="py-3 px-4">
                                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="viewBillDetails(this)">View</button>
                                            <button class="text-green-600 hover:text-green-800 font-medium" onclick="printBill(this)">Print</button>
                                        </td>
                                    </tr>
                                    <tr class="hover:bg-gray-50">
                                        <td class="py-3 px-4">#2025002</td>
                                        <td class="py-3 px-4">2025-07-11</td>
                                        <td class="py-3 px-4">Bob Johnson</td>
                                        <td class="py-3 px-4">₹ 6200.00</td>
                                        <td class="py-3 px-4">
                                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="viewBillDetails(this)">View</button>
                                            <button class="text-green-600 hover:text-green-800 font-medium" onclick="printBill(this)">Print</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- Reports / Sales History Section -->
                <section id="reports-sales-history" class="dashboard-section">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Reports & Sales History</h1>
                    <p class="text-gray-600 mb-8">View various sales reports and historical data.</p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div class="bg-blue-50 p-6 rounded-lg shadow-md">
                            <h2 class="text-2xl font-semibold text-blue-800 mb-4">Sales Summary</h2>
                            <p class="text-gray-700 mb-2"><strong>Daily Sales:</strong> ₹ 15,000</p>
                            <p class="text-gray-700 mb-2"><strong>Weekly Sales:</strong> ₹ 85,000</p>
                            <p class="text-gray-700"><strong>Monthly Sales:</strong> ₹ 3,20,000</p>
                        </div>
                        <div class="bg-green-50 p-6 rounded-lg shadow-md">
                            <h2 class="text-2xl font-semibold text-green-800 mb-4">Most Sold Tyres</h2>
                            <ul class="list-disc list-inside text-gray-700">
                                <li>MRF ZVTS (175/70R13) - 500 units</li>
                                <li>Goodyear Assurance (195/65R15) - 350 units</li>
                                <li>Apollo Alnac 4G (215/60R17) - 200 units</li>
                            </ul>
                        </div>
                    </div>

                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Total Earnings Overview</h2>
                        <p class="text-gray-700">This section would display charts and graphs for total earnings over time.</p>
                        <div class="bg-gray-100 h-64 flex items-center justify-center rounded-lg text-gray-500">
                            [Placeholder for Sales Chart]
                        </div>
                    </div>

                    <div>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Export Options</h2>
                        <div class="flex gap-4">
                            <button class="bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200" onclick="exportReport('excel')">Export as Excel</button>
                            <button class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200" onclick="exportReport('pdf')">Export as PDF</button>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <!-- Custom Modal for Alerts/Confirmations -->
    <div id="custom-modal" class="modal hidden">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h3 id="modal-title" class="text-xl font-semibold mb-4"></h3>
            <p id="modal-message" class="mb-6"></p>
            <div id="modal-actions" class="flex justify-end gap-3">
                <!-- Buttons will be dynamically added here -->
            </div>
        </div>
    </div>

    <script>
        let currentBillItemId = 1;

        document.addEventListener('DOMContentLoaded', () => {
            const loginForm = document.getElementById('login-form');
            const loginScreen = document.getElementById('login-screen');
            const dashboardLayout = document.getElementById('dashboard-layout');
            const logoutButton = document.getElementById('logout-button');
            const sidebarLinks = document.querySelectorAll('.sidebar-link');
            const addTyreForm = document.getElementById('add-tyre-form');
            const updateStockForm = document.getElementById('update-stock-form');
            const generateBillForm = document.getElementById('generate-bill-form');
            const addBillItemButton = document.getElementById('add-bill-item');
            const billItemsContainer = document.getElementById('bill-items-container');

            // Handle Login
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                const loginMessage = document.getElementById('login-message');

                // Simple hardcoded login for demonstration
                if (username === 'admin' && password === '123') {
                    loginScreen.classList.add('hidden');
                    dashboardLayout.classList.remove('hidden');
                    loginMessage.classList.add('hidden');
                    showSection('dashboard-overview'); // Show dashboard overview on successful login
                } else {
                    loginMessage.textContent = 'Invalid username or password.';
                    loginMessage.classList.remove('hidden');
                }
            });

            // Handle Logout
            logoutButton.addEventListener('click', (e) => {
                e.preventDefault();
                dashboardLayout.classList.add('hidden');
                loginScreen.classList.remove('hidden');
                document.getElementById('login-form').reset(); // Clear login form
                document.getElementById('login-message').classList.add('hidden'); // Hide login message
                showModal('Logged Out', 'You have been successfully logged out.', 'alert');
            });

            // Handle Sidebar Navigation
            sidebarLinks.forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    const targetSectionId = e.target.dataset.section;
                    showSection(targetSectionId);

                    // Update active class for sidebar links
                    sidebarLinks.forEach(l => l.classList.remove('active'));
                    e.target.classList.add('active');
                });
            });

            // Handle Add Tyre Form Submission
            addTyreForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('tyre-name').value;
                const size = document.getElementById('tyre-size').value;
                const price = parseFloat(document.getElementById('tyre-price').value).toFixed(2);
                const stock = document.getElementById('tyre-stock').value;
                const type = document.getElementById('tyre-type').value;

                // Simulate adding to a list
                const tyreList = document.getElementById('tyre-list');
                const newRow = `
                    <tr class="hover:bg-gray-50">
                        <td class="py-3 px-4">${name}</td>
                        <td class="py-3 px-4">${size}</td>
                        <td class="py-3 px-4">₹ ${price}</td>
                        <td class="py-3 px-4">${stock}</td>
                        <td class="py-3 px-4">${type}</td>
                        <td class="py-3 px-4">
                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="editTyre(this)">Edit</button>
                            <button class="text-red-600 hover:text-red-800 font-medium" onclick="deleteTyre(this)">Delete</button>
                        </td>
                    </tr>
                `;
                tyreList.insertAdjacentHTML('beforeend', newRow);
                addTyreForm.reset();
                showModal('Tyre Added', `Tyre "${name}" added successfully!`, 'alert');
            });

            // Handle Update Stock Form Submission
            updateStockForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const selectedTyre = document.getElementById('stock-tyre-select').value;
                const quantity = parseInt(document.getElementById('stock-quantity').value);

                if (!selectedTyre) {
                    showModal('Error', 'Please select a tyre to update stock.', 'alert');
                    return;
                }

                // Simulate stock update
                showModal('Stock Updated', `Stock for "${selectedTyre}" updated by ${quantity}.`, 'alert');
                updateStockForm.reset();
            });

            // Handle Add Bill Item
            addBillItemButton.addEventListener('click', () => {
                currentBillItemId++;
                const newItemHtml = `
                    <div class="bill-item grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div>
                            <label for="bill-tyre-${currentBillItemId}" class="block text-gray-700 text-sm font-medium mb-2">Tyre</label>
                            <select id="bill-tyre-${currentBillItemId}" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-tyre-select" data-item-id="${currentBillItemId}" required>
                                <option value="">-- Select Tyre --</option>
                                <option value="Goodyear Assurance" data-price="4200">Goodyear Assurance (₹ 4200)</option>
                                <option value="MRF ZVTS" data-price="3100">MRF ZVTS (₹ 3100)</option>
                                <option value="Apollo Alnac 4G" data-price="6800">Apollo Alnac 4G (₹ 6800)</option>
                                <option value="Ceat Milaze" data-price="2800">Ceat Milaze (₹ 2800)</option>
                            </select>
                        </div>
                        <div>
                            <label for="bill-quantity-${currentBillItemId}" class="block text-gray-700 text-sm font-medium mb-2">Quantity</label>
                            <input type="number" id="bill-quantity-${currentBillItemId}" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-quantity-input" data-item-id="${currentBillItemId}" value="1" min="1" required>
                        </div>
                        <div>
                            <label for="bill-price-${currentBillItemId}" class="block text-gray-700 text-sm font-medium mb-2">Price/Unit</label>
                            <input type="text" id="bill-price-${currentBillItemId}" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight bg-gray-200 cursor-not-allowed" readonly value="0.00">
                        </div>
                        <div class="flex items-center">
                            <button type="button" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200 remove-bill-item-btn">Remove</button>
                        </div>
                    </div>
                `;
                billItemsContainer.insertAdjacentHTML('beforeend', newItemHtml);
                attachBillItemListeners(); // Re-attach listeners for new elements
                calculateBillTotal();
            });

            // Handle Generate Bill Form Submission
            generateBillForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const customerName = document.getElementById('customer-name').value || 'Walk-in Customer';
                const customerMobile = document.getElementById('customer-mobile').value;
                const billTotal = document.getElementById('bill-total').textContent;

                const billItems = [];
                document.querySelectorAll('.bill-item').forEach(item => {
                    const tyreSelect = item.querySelector('.bill-tyre-select');
                    const quantityInput = item.querySelector('.bill-quantity-input');
                    if (tyreSelect.value && quantityInput.value) {
                        billItems.push({
                            tyre: tyreSelect.value,
                            quantity: parseInt(quantityInput.value),
                            pricePerUnit: parseFloat(tyreSelect.selectedOptions[0].dataset.price)
                        });
                    }
                });

                if (billItems.length === 0) {
                    showModal('Error', 'Please add at least one tyre to the bill.', 'alert');
                    return;
                }

                // Simulate bill generation and storage
                const billNo = `#${Math.floor(Math.random() * 100000) + 2025000}`;
                const billDate = new Date().toISOString().slice(0, 10);

                const billRecordsList = document.getElementById('bill-records-list');
                const newBillRow = `
                    <tr class="hover:bg-gray-50">
                        <td class="py-3 px-4">${billNo}</td>
                        <td class="py-3 px-4">${billDate}</td>
                        <td class="py-3 px-4">${customerName}</td>
                        <td class="py-3 px-4">${billTotal}</td>
                        <td class="py-3 px-4">
                            <button class="text-blue-600 hover:text-blue-800 font-medium mr-2" onclick="viewBillDetails(this)">View</button>
                            <button class="text-green-600 hover:text-green-800 font-medium" onclick="printBill(this)">Print</button>
                        </td>
                    </tr>
                `;
                billRecordsList.insertAdjacentHTML('beforeend', newBillRow);
                generateBillForm.reset();
                // Reset bill items to one default item
                billItemsContainer.innerHTML = `
                    <div class="bill-item grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div>
                            <label for="bill-tyre-1" class="block text-gray-700 text-sm font-medium mb-2">Tyre</label>
                            <select id="bill-tyre-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-tyre-select" data-item-id="1" required>
                                <option value="">-- Select Tyre --</option>
                                <option value="Goodyear Assurance" data-price="4200">Goodyear Assurance (₹ 4200)</option>
                                <option value="MRF ZVTS" data-price="3100">MRF ZVTS (₹ 3100)</option>
                                <option value="Apollo Alnac 4G" data-price="6800">Apollo Alnac 4G (₹ 6800)</option>
                                <option value="Ceat Milaze" data-price="2800">Ceat Milaze (₹ 2800)</option>
                            </select>
                        </div>
                        <div>
                            <label for="bill-quantity-1" class="block text-gray-700 text-sm font-medium mb-2">Quantity</label>
                            <input type="number" id="bill-quantity-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bill-quantity-input" data-item-id="1" value="1" min="1" required>
                        </div>
                        <div>
                            <label for="bill-price-1" class="block text-gray-700 text-sm font-medium mb-2">Price/Unit</label>
                            <input type="text" id="bill-price-1" class="shadow-sm appearance-none border rounded-md w-full py-2 px-3 text-gray-700 leading-tight bg-gray-200 cursor-not-allowed" readonly value="0.00">
                        </div>
                        <div class="flex items-center">
                            <button type="button" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200 remove-bill-item-btn">Remove</button>
                        </div>
                    </div>
                `;
                currentBillItemId = 1; // Reset counter
                attachBillItemListeners();
                calculateBillTotal(); // Recalculate total after reset

                showModal('Bill Generated', `Bill ${billNo} generated successfully for ${customerName}! Total: ${billTotal}`, 'alert');
            });

            // Initial attachment of listeners for bill items
            attachBillItemListeners();
            calculateBillTotal(); // Calculate initial total
        });

        // Function to show/hide dashboard sections
        function showSection(sectionId) {
            document.querySelectorAll('.dashboard-section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(sectionId).classList.add('active');

            // Update active class for sidebar links
            document.querySelectorAll('.sidebar-link').forEach(link => {
                if (link.dataset.section === sectionId) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
        }

        // Functions for Tyre Product Management (simulated)
        function editTyre(button) {
            const row = button.closest('tr');
            const name = row.children[0].textContent;
            showModal('Edit Tyre', `Simulating edit for tyre: ${name}. (This would open an edit form)`, 'alert');
        }

        function deleteTyre(button) {
            const row = button.closest('tr');
            const name = row.children[0].textContent;
            showModal('Confirm Delete', `Are you sure you want to delete tyre: ${name}?`, 'confirm', () => {
                row.remove();
                showModal('Deleted', `Tyre "${name}" has been deleted.`, 'alert');
            });
        }

        // Functions for Billing System (simulated)
        function attachBillItemListeners() {
            document.querySelectorAll('.bill-tyre-select').forEach(select => {
                select.onchange = (e) => {
                    const itemId = e.target.dataset.itemId;
                    const selectedOption = e.target.selectedOptions[0];
                    const priceInput = document.getElementById(`bill-price-${itemId}`);
                    if (selectedOption && selectedOption.dataset.price) {
                        priceInput.value = parseFloat(selectedOption.dataset.price).toFixed(2);
                    } else {
                        priceInput.value = '0.00';
                    }
                    calculateBillTotal();
                };
            });

            document.querySelectorAll('.bill-quantity-input').forEach(input => {
                input.oninput = () => calculateBillTotal();
            });

            document.querySelectorAll('.remove-bill-item-btn').forEach(button => {
                button.onclick = (e) => {
                    const itemDiv = e.target.closest('.bill-item');
                    if (document.querySelectorAll('.bill-item').length > 1) {
                        itemDiv.remove();
                        calculateBillTotal();
                    } else {
                        showModal('Cannot Remove', 'You must have at least one item in the bill.', 'alert');
                    }
                };
            });
        }

        function calculateBillTotal() {
            let total = 0;
            document.querySelectorAll('.bill-item').forEach(item => {
                const tyreSelect = item.querySelector('.bill-tyre-select');
                const quantityInput = item.querySelector('.bill-quantity-input');
                const priceInput = item.querySelector('.bill-price-input'); // This is not used, but kept for reference

                const quantity = parseInt(quantityInput.value) || 0;
                const pricePerUnit = parseFloat(tyreSelect.selectedOptions[0]?.dataset.price) || 0;
                total += quantity * pricePerUnit;
            });
            document.getElementById('bill-total').textContent = `₹ ${total.toFixed(2)}`;
        }

        function searchBills() {
            const billNo = document.getElementById('search-bill-number').value;
            const billDate = document.getElementById('search-bill-date').value;
            const customer = document.getElementById('search-bill-customer').value;
            showModal('Search Bills', `Simulating search for Bill No: "${billNo}", Date: "${billDate}", Customer: "${customer}".`, 'alert');
        }

        function viewBillDetails(button) {
            const row = button.closest('tr');
            const billNo = row.children[0].textContent;
            showModal('Bill Details', `Simulating viewing details for bill: ${billNo}. (This would show a detailed bill)`, 'alert');
        }

        function printBill(button) {
            const row = button.closest('tr');
            const billNo = row.children[0].textContent;
            showModal('Print Bill', `Simulating printing bill: ${billNo}. (This would generate a printable PDF/HTML)`, 'alert');
        }

        // Functions for Reports (simulated)
        function exportReport(format) {
            showModal('Export Report', `Simulating export of report as ${format.toUpperCase()}.`, 'alert');
        }

        // Custom Modal Functions
        const customModal = document.getElementById('custom-modal');
        const modalTitle = document.getElementById('modal-title');
        const modalMessage = document.getElementById('modal-message');
        const modalActions = document.getElementById('modal-actions');

        function showModal(title, message, type, confirmCallback = null) {
            modalTitle.textContent = title;
            modalMessage.textContent = message;
            modalActions.innerHTML = ''; // Clear previous buttons

            if (type === 'alert') {
                const okButton = document.createElement('button');
                okButton.textContent = 'OK';
                okButton.className = 'bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                okButton.onclick = closeModal;
                modalActions.appendChild(okButton);
            } else if (type === 'confirm') {
                const cancelButton = document.createElement('button');
                cancelButton.textContent = 'Cancel';
                cancelButton.className = 'bg-gray-400 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                cancelButton.onclick = closeModal;

                const confirmButton = document.createElement('button');
                confirmButton.textContent = 'Confirm';
                confirmButton.className = 'bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                confirmButton.onclick = () => {
                    if (confirmCallback) {
                        confirmCallback();
                    }
                    closeModal();
                };
                modalActions.appendChild(cancelButton);
                modalActions.appendChild(confirmButton);
            }

            customModal.classList.remove('hidden');
        }

        function closeModal() {
            customModal.classList.add('hidden');
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == customModal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
