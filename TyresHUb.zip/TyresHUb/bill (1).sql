-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2025 at 10:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tyres`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(11) NOT NULL,
  `bill_number` varchar(50) DEFAULT NULL,
  `billing_date` date DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `brand1` varchar(50) DEFAULT NULL,
  `model1` varchar(50) DEFAULT NULL,
  `qty1` int(11) DEFAULT NULL,
  `price1` decimal(10,2) DEFAULT NULL,
  `subtotal1` decimal(10,2) DEFAULT NULL,
  `brand2` varchar(50) DEFAULT NULL,
  `model2` varchar(50) DEFAULT NULL,
  `qty2` int(11) DEFAULT NULL,
  `price2` decimal(10,2) DEFAULT NULL,
  `subtotal2` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `bill_number`, `billing_date`, `customer_name`, `contact_number`, `brand1`, `model1`, `qty1`, `price1`, `subtotal1`, `brand2`, `model2`, `qty2`, `price2`, `subtotal2`, `total_amount`, `payment_method`) VALUES
(1, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(2, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(3, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(4, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(5, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(6, '3', '2025-07-08', 'shri', '8788', 'MRF', 'Radial X', 10, 1000.00, 10000.00, 'MRF', 'GripPro', 10, 5.00, 50.00, 10050.00, 'Card'),
(7, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(8, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(9, '13', '2025-07-08', 'vishal', '8788', 'MRF', 'Radial X', 20, 2000.00, 40000.00, 'Apollo', 'GripPro', 20, 1000.00, 20000.00, 60000.00, 'Card'),
(11, '13', '2025-07-12', 'shri', '8788', 'Apollo', 'Radial X', 10, 200.00, 2000.00, 'Apollo', 'Radial X', 200, 200.00, 40000.00, 42000.00, 'Cash'),
(12, '1', '2025-07-13', 'om', '8788', 'MRF', 'GripPro', 10, 1000.00, 10000.00, 'Apollo', 'Radial X', 100, 100.00, 10000.00, 20000.00, 'Cash'),
(13, '13', '2025-08-11', 'shri', '8788', 'Apollo', 'Radial X', 10, 100.00, 1000.00, 'Apollo', 'GripPro', 20, 200.00, 4000.00, 5000.00, 'Cash');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
