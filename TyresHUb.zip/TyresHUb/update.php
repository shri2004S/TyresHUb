<?php
include 'dbconn.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if it's an edit operation (from the hidden field in bill.php)
    if (!isset($_POST['is_edit']) || $_POST['is_edit'] != '1') {
        die("Invalid access. This page is for updating records.");
    }

    // Get the original bill number to identify the record to update
    $original_bill_number = isset($_POST['original_bill_number']) ? trim($_POST['original_bill_number']) : '';

    // Get all other form data
    $bill_number = isset($_POST['bill_number']) ? trim($_POST['bill_number']) : '';
    $billing_date = isset($_POST['billing_date']) ? trim($_POST['billing_date']) : '';
    $customer_name = isset($_POST['customer_name']) ? trim($_POST['customer_name']) : '';
    $contact_number = isset($_POST['contact_number']) ? trim($_POST['contact_number']) : '';

    $brand1 = isset($_POST['brand1']) ? trim($_POST['brand1']) : '';
    $model1 = isset($_POST['model1']) ? trim($_POST['model1']) : '';
    $qty1 = isset($_POST['qty1']) ? intval($_POST['qty1']) : 0; // Use intval for quantities
    $price1 = isset($_POST['price1']) ? floatval($_POST['price1']) : 0.00; // Use floatval for prices
    $subtotal1 = isset($_POST['subtotal1']) ? floatval($_POST['subtotal1']) : 0.00;

    $brand2 = isset($_POST['brand2']) ? trim($_POST['brand2']) : '';
    $model2 = isset($_POST['model2']) ? trim($_POST['model2']) : '';
    $qty2 = isset($_POST['qty2']) ? intval($_POST['qty2']) : 0;
    $price2 = isset($_POST['price2']) ? floatval($_POST['price2']) : 0.00;
    $subtotal2 = isset($_POST['subtotal2']) ? floatval($_POST['subtotal2']) : 0.00;

    $total_amount = isset($_POST['total_amount']) ? floatval($_POST['total_amount']) : 0.00;
    $payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';

    // Basic validation
    if (empty($original_bill_number) || empty($bill_number) || empty($billing_date) || empty($customer_name) || empty($contact_number) || empty($total_amount)) {
        die("Error: Required fields are missing. Please go back and fill all necessary information.");
    }

    // SQL UPDATE statement
    // We update all fields. The WHERE clause uses the original_bill_number
    // in case the user also changed the bill_number itself in the form.
    $sql = "UPDATE bill SET
                bill_number = ?,
                billing_date = ?,
                customer_name = ?,
                contact_number = ?,
                brand1 = ?,
                model1 = ?,
                qty1 = ?,
                price1 = ?,
                subtotal1 = ?,
                brand2 = ?,
                model2 = ?,
                qty2 = ?,
                price2 = ?,
                subtotal2 = ?,
                total_amount = ?,
                payment_method = ?
            WHERE bill_number = ?";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ssssssiidssssidss", // Corrected: Added an 's' at the end
        $bill_number,
        $billing_date,
        $customer_name,
        $contact_number,
        $brand1,
        $model1,
        $qty1,
        $price1,
        $subtotal1,
        $brand2,
        $model2,
        $qty2,
        $price2,
        $subtotal2,
        $total_amount,
        $payment_method,
        $original_bill_number // This is for the WHERE clause
    );

    // Execute the statement
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Update Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
            echo "<div class='container mt-5'><div class='alert alert-success' role='alert'>";
            echo "Bill <b>" . htmlspecialchars($bill_number) . "</b> updated successfully!";
            echo "</div><a href='bill.php?bill_number=" . urlencode($bill_number) . "' class='btn btn-primary'>View Updated Bill</a> ";
            echo "<a href='search.php' class='btn btn-secondary'>Back to Search</a></div></body></html>";
        } else {
            echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Update Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
            echo "<div class='container mt-5'><div class='alert alert-info' role='alert'>";
            echo "No changes were made to bill <b>" . htmlspecialchars($bill_number) . "</b> (data might be identical or bill number not found).";
            echo "</div><a href='bill.php?bill_number=" . urlencode($bill_number) . "' class='btn btn-primary'>View Bill</a> ";
            echo "<a href='search.php' class='btn btn-secondary'>Back to Search</a></div></body></html>";
        }
    } else {
        echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Update Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
        echo "<div class='container mt-5'><div class='alert alert-danger' role='alert'>";
        echo "Error updating record: " . htmlspecialchars($stmt->error);
        echo "</div><a href='bill.php?bill_number=" . urlencode($original_bill_number) . "' class='btn btn-warning'>Try Again</a> ";
        echo "<a href='search.php' class='btn btn-secondary'>Back to Search</a></div></body></html>";
    }

    $stmt->close();
} else {
    // If not a POST request, redirect or show an error
    header('Location: bill.php'); // Redirect to the billing page or an error page
    exit();
}

$conn->close(); // Close the database connection
?>