<?php
include 'dbconn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bill_number = $_POST['bill_number'];
    $billing_date = $_POST['billing_date'];
    $customer_name = $_POST['customer_name'];
    $contact_number = $_POST['contact_number'];

    $brand1 = $_POST['brand1'];
    $model1 = $_POST['model1'];
    $qty1 = $_POST['qty1'];
    $price1 = $_POST['price1'];
    $subtotal1 = $_POST['subtotal1'];

    $brand2 = $_POST['brand2'];
    $model2 = $_POST['model2'];
    $qty2 = $_POST['qty2'];
    $price2 = $_POST['price2'];
    $subtotal2 = $_POST['subtotal2'];

    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method'];

    $sql = "INSERT INTO bill (
        bill_number, billing_date, customer_name, contact_number,
        brand1, model1, qty1, price1, subtotal1,
        brand2, model2, qty2, price2, subtotal2,
        total_amount, payment_method
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssssssiddssiddss",
        $bill_number, $billing_date, $customer_name, $contact_number,
        $brand1, $model1, $qty1, $price1, $subtotal1,
        $brand2, $model2, $qty2, $price2, $subtotal2,
        $total_amount, $payment_method
    );

    if ($stmt->execute()) {
        echo "<script>alert('Bill inserted successfully'); window.location.href='bill.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
