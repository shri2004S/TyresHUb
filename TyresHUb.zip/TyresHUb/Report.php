<?php
include 'dbconn.php'; // This connects to the 'tyres' database

$results = [];
$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = isset($_POST['billing_date']) ? $_POST['billing_date'] : '';
    $bill_number = isset($_POST['bill_number']) ? $_POST['bill_number'] : '';

    if (!empty($date) && !empty($bill_number)) {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM bill WHERE billing_date = ? AND bill_number = ?");
        $stmt->bind_param("ss", $date, $bill_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $results = $result->fetch_all(MYSQLI_ASSOC);
        } else {
            $error = "No records found for date <b>$date</b> and bill number <b>$bill_number</b>.";
        }
        $stmt->close();
    } else {
        $error = "Please enter both billing date and bill number.";
    }
}
// Close connection after all database operations are done
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Search Billing</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="min-height: 100vh;">

<div class="container">
  <div class="card shadow p-4 mx-auto mt-5" style="max-width: 800px;"> <h4 class="mb-3 text-center">Search Billing Records by Date and Bill Number</h4>

    <form method="POST">
      <div class="mb-3">
        <label for="billing_date" class="form-label">Billing Date:</label>
        <input type="date" name="billing_date" id="billing_date" class="form-control" required />
      </div>

      <div class="mb-3">
        <label for="bill_number" class="form-label">Bill Number:</label>
        <input type="text" name="bill_number" id="bill_number" class="form-control" placeholder="e.g., INV001" required />
      </div>

      <button type="submit" class="btn btn-primary w-100">Search</button>
    </form>

    <?php if (!empty($error)): ?>
      <div class="alert alert-warning mt-3"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if (!empty($results)): ?>
      <div class="table-responsive mt-4">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Bill No</th>
              <th>Customer</th>
              <th>Contact</th>
              <th>Total (₹)</th>
              <th>Payment</th>
              <th colspan="2">Action</th> </tr>
          </thead>
          <tbody>
            <?php foreach ($results as $index => $row): ?>
            <tr>
              <td><?= $index + 1 ?></td>
              <td><?= htmlspecialchars($row['bill_number']) ?></td>
              <td><?= htmlspecialchars($row['customer_name']) ?></td>
              <td><?= htmlspecialchars($row['contact_number']) ?></td>
              <td><?= number_format($row['total_amount'], 2) ?></td>
              <td><?= htmlspecialchars($row['payment_method']) ?></td>
              <td>
                <a href="bill.php?bill_number=<?= urlencode($row['bill_number']) ?>" class="btn btn-sm btn-info">Edit</a>
              </td>
              <td>
                <a href="delete.php?bill_number=<?= urlencode($row['bill_number']) ?>"
                   class="btn btn-sm btn-danger"
                   onclick="return confirm('Are you sure you want to delete bill number <?= htmlspecialchars($row['bill_number']) ?>? This action cannot be undone.');">
                   Delete
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

</body>
</html>