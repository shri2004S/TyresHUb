<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "tyres"; // ✅ This is your actual DB name

$conn = mysqli_connect($host, $user, $pass, $dbname); // ✅ Use $dbname here

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
