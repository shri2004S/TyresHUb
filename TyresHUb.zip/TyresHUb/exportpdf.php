<?php
require 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;

include 'dbconn.php';

$month = $_POST['month'];
$year = $_POST['year'];

ob_start(); // Start output buffering
?>

<h3>Monthly Sales Report - <?= date("F", mktime(0, 0, 0, $month, 10)) ?> <?= $year ?></h3>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
    <tr>
        <th>Brand</th>
        <th>Model</th>
        <th>Total Quantity</th>
        <th>Total Subtotal (₹)</th>
    </tr>

<?php
$stmt = $conn->prepare("
    SELECT brand, model, SUM(qty) AS total_qty, SUM(subtotal) AS total_subtotal
    FROM (
        SELECT brand1 AS brand, model1 AS model, qty1 AS qty, subtotal1 AS subtotal
        FROM bill WHERE YEAR(billing_date)=? AND MONTH(billing_date)=? AND brand1 IS NOT NULL
        UNION ALL
        SELECT brand2 AS brand, model2 AS model, qty2 AS qty, subtotal2 AS subtotal
        FROM bill WHERE YEAR(billing_date)=? AND MONTH(billing_date)=? AND brand2 IS NOT NULL
    ) AS combined
    GROUP BY brand, model
    ORDER BY total_qty DESC
");
$stmt->bind_param("iiii", $year, $month, $year, $month);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['brand']}</td>
        <td>{$row['model']}</td>
        <td>{$row['total_qty']}</td>
        <td>₹" . number_format($row['total_subtotal'], 2) . "</td>
    </tr>";
}
$conn->close();
?>
</table>

<?php
$html = ob_get_clean(); // Get buffered content

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("monthly_sales_{$month}_{$year}.pdf", ["Attachment" => 1]);
?>


