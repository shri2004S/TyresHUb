<?php
include 'dbconn.php'; // Include your database connection file

$selected_month = '';
$selected_year = '';
$monthly_total_sales = 0;
$tyre_sales_breakdown = [];
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_month = isset($_POST['month']) ? (int)$_POST['month'] : 0;
    $selected_year = isset($_POST['year']) ? (int)$_POST['year'] : 0;

    if (!is_numeric($selected_month) || $selected_month < 1 || $selected_month > 12 ||
        !is_numeric($selected_year) || $selected_year < 1900 || $selected_year > 2100) {
        $error_message = "Invalid month or year selected.";
    } else {
        $stmt_total = $conn->prepare("SELECT SUM(total_amount) AS monthly_total FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ?");
        if ($stmt_total === false) {
            $error_message = "Error preparing total sales statement: " . $conn->error;
        } else {
            $stmt_total->bind_param("ii", $selected_year, $selected_month);
            $stmt_total->execute();
            $result_total = $stmt_total->get_result();
            if ($result_total && $row_total = $result_total->fetch_assoc()) {
                $monthly_total_sales = $row_total['monthly_total'] ?? 0;
            }
            $stmt_total->close();
        }

        $stmt_breakdown = $conn->prepare("
            SELECT brand, model, SUM(qty) AS total_qty, SUM(subtotal) AS total_subtotal
            FROM (
                SELECT brand1 AS brand, model1 AS model, qty1 AS qty, subtotal1 AS subtotal
                FROM bill
                WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand1 IS NOT NULL AND brand1 != ''
                UNION ALL
                SELECT brand2 AS brand, model2 AS model, qty2 AS qty, subtotal2 AS subtotal
                FROM bill
                WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand2 IS NOT NULL AND brand2 != ''
            ) AS combined_tyres
            GROUP BY brand, model
            ORDER BY total_qty DESC, brand ASC, model ASC;
        ");
        if ($stmt_breakdown === false) {
            $error_message = "Error preparing tyre breakdown statement: " . $conn->error;
        } else {
            $stmt_breakdown->bind_param("iiii", $selected_year, $selected_month, $selected_year, $selected_month);
            $stmt_breakdown->execute();
            $result_breakdown = $stmt_breakdown->get_result();
            while ($row = $result_breakdown->fetch_assoc()) {
                $tyre_sales_breakdown[] = $row;
            }
            $stmt_breakdown->close();
        }

        if (empty($tyre_sales_breakdown) && $monthly_total_sales == 0 && empty($error_message)) {
            $error_message = "No sales records found for " . date("F", mktime(0, 0, 0, $selected_month, 10)) . " " . $selected_year . ".";
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Monthly Sales Report - The Perfect Tyres</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-size: 14px;
        }
        .container {
            max-width: 900px;
            margin-top: 30px;
            margin-bottom: 30px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .form-select {
            padding: 0.4rem 0.75rem;
            font-size: 0.9rem;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .company-logo {
            max-width: 150px; /* Adjust as needed */
            height: auto;
            display: block;
            margin: 0 auto 20px auto; /* Center the image and add some bottom margin */
        }
    </style>
</head>
<body>

<div class="container">
    <img src="tyres13.png" alt="The Perfect Tyres Logo" class="company-logo">
    <h3 class="text-center mb-4">Monthly Sales Report</h3>

    <div class="mb-3">
        <a href="search.php" class="btn btn-secondary">Back to Search</a>
    </div>

    <form method="POST" class="mb-4">
        <div class="row g-3 align-items-end">
            <div class="col-md-5">
                <label for="month" class="form-label">Select Month:</label>
                <select id="month" name="month" class="form-select">
                    <?php
                    $months = [
                        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                    ];
                    foreach ($months as $num => $name) {
                        $selected = ($selected_month == $num) ? 'selected' : '';
                        echo "<option value='{$num}' {$selected}>{$name}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-5">
                <label for="year" class="form-label">Select Year:</label>
                <select id="year" name="year" class="form-select">
                    <?php
                    $current_year = date('Y');
                    for ($y = $current_year; $y >= $current_year - 5; $y--) {
                        $selected = ($selected_year == $y) ? 'selected' : '';
                        echo "<option value='{$y}' {$selected}>{$y}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Generate Report</button>
            </div>
        </div>

        <?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($error_message)): ?>
        <div class="mt-4 d-flex gap-3">
            <form method="post" action="excel1.php" target="_blank">
                <input type="hidden" name="month" value="<?= htmlspecialchars($selected_month) ?>">
                <input type="hidden" name="year" value="<?= htmlspecialchars($selected_year) ?>">
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-file-earmark-excel"></i> Export as Excel
                </button>
            </form>

            <form method="post" action="imgpdf.php" target="_blank">
                <input type="hidden" name="month" value="<?= htmlspecialchars($selected_month) ?>">
                <input type="hidden" name="year" value="<?= htmlspecialchars($selected_year) ?>">
                <button type="submit" class="btn btn-danger">
                    <i class="bi bi-file-earmark-pdf"></i> Export as PDF
                </button>
            </form>
        </div>
        <?php endif; ?>
    </form>

    <?php if (!empty($error_message)): ?>
        <div class="alert alert-warning mt-3"><?= htmlspecialchars($error_message) ?></div>
    <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
        <h4 class="mt-4 mb-3">Report for <?= date("F", mktime(0, 0, 0, $selected_month, 10)) . " " . $selected_year ?></h4>

        <div class="card mb-4">
            <div class="card-header">Total Sales Amount</div>
            <div class="card-body">
                <h5 class="card-title">₹<?= number_format($monthly_total_sales, 2) ?></h5>
            </div>
        </div>

        <h5 class="mt-4 mb-3">Tyre Sales Breakdown by Type</h5>
        <?php if (!empty($tyre_sales_breakdown)): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Brand</th>
                            <th>Model</th>
                            <th>Total Quantity Sold</th>
                            <th>Total Amount Sold </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tyre_sales_breakdown as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['brand']) ?></td>
                                <td><?= htmlspecialchars($item['model']) ?></td>
                                <td><?= htmlspecialchars($item['total_qty']) ?></td>
                                <td><?= number_format($item['total_subtotal'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No specific tyre type sales found for this month.</div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>