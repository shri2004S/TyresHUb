<?php
require 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
include 'dbconn.php';

$month = $_POST['month'];
$year = $_POST['year'];

$monthly_total_sales = 0;
$tyre_sales_breakdown = [];

$stmt_total = $conn->prepare("SELECT SUM(total_amount) AS monthly_total FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ?");
$stmt_total->bind_param("ii", $year, $month);
$stmt_total->execute();
$result_total = $stmt_total->get_result();
if ($result_total && $row_total = $result_total->fetch_assoc()) {
    $monthly_total_sales = $row_total['monthly_total'] ?? 0;
}
$stmt_total->close();

$stmt_breakdown = $conn->prepare("
    SELECT brand, model, SUM(qty) AS total_qty, SUM(subtotal) AS total_subtotal
    FROM (
        SELECT brand1 AS brand, model1 AS model, qty1 AS qty, subtotal1 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand1 IS NOT NULL
        UNION ALL
        SELECT brand2 AS brand, model2 AS model, qty2 AS qty, subtotal2 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand2 IS NOT NULL
    ) AS combined
    GROUP BY brand, model
    ORDER BY total_qty DESC
");
$stmt_breakdown->bind_param("iiii", $year, $month, $year, $month);
$stmt_breakdown->execute();
$result_breakdown = $stmt_breakdown->get_result();
while ($row = $result_breakdown->fetch_assoc()) {
    $tyre_sales_breakdown[] = $row;
}
$stmt_breakdown->close();
$conn->close();

$month_name = date("F", mktime(0, 0, 0, $month, 10));

// Path to your image file. Adjust this path if 'tyres13.jpg' is not in the same directory as 'pdfd.php'.
// For Dompdf, it's often best to use an absolute path or ensure the path is correctly resolved.
// For simplicity, assuming tyres13.jpg is in the same directory as this script.
$image_path = 'tyres13.jpg'; 

$html = "
<html>
<head>
    <style>
        body { font-family: sans-serif; }
        .header-section {
            text-align: center;
            margin-bottom: 20px;
        }
        .company-logo {
            max-width: 150px; /* Adjust as needed */
            height: auto;
            margin-bottom: 10px;
        }
        h2, h4 {
            margin: 5px 0;
        }
        hr {
            border: 0;
            border-top: 1px solid #eee;
            margin: 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class='header-section'>
        <img src='{$image_path}' alt='The Perfect Tyres Logo' class='company-logo'>
        <h2>The Perfect Tyres</h2>
        <h4>Monthly Sales Report - {$month_name} {$year}</h4>
    </div>
    <hr>
    <h4>Total Sales: ₹" . number_format($monthly_total_sales, 2) . "</h4>
    <table>
        <thead>
            <tr>
                <th>Brand</th>
                <th>Model</th>
                <th>Qty</th>
                <th>Total (₹)</th>
            </tr>
        </thead>
        <tbody>";

if (!empty($tyre_sales_breakdown)) {
    foreach ($tyre_sales_breakdown as $item) {
        $html .= "<tr>
            <td>{$item['brand']}</td>
            <td>{$item['model']}</td>
            <td>{$item['total_qty']}</td>
            <td>" . number_format($item['total_subtotal'], 2) . "</td>
        </tr>";
    }
} else {
    $html .= "<tr><td colspan='4' align='center'>No data available</td></tr>";
}
$html .= "</tbody></table></body></html>";

$dompdf = new Dompdf();

// Enable remote fetching if the image is from a URL, though here it's local.
// For local files, ensure the path is correct and Dompdf has read access.
$dompdf->getOptions()->set('isHtml5ParserEnabled', true);
$dompdf->getOptions()->set('isRemoteEnabled', true); 

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("Sales_Report_{$month_name}_{$year}.pdf", ["Attachment" => true]);
?>