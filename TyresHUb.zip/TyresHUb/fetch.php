<?php
include 'dbconn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['billing_date'];
    $bill_number = $_POST['bill_number'];
    

    if (empty($date)) {
        echo "Please enter a billing date.";
        exit;
    }

    $query = "SELECT * FROM bill WHERE billing_date = '$date'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo "<h3>Billing Records for: $date</h3>";
        echo "<table border='1' cellpadding='10'>
                <tr>
                    <th>Bill No</th>
                    <th>Customer</th>
                    <th>Contact</th>
                    <th>Total Amount</th>
                    <th>Payment</th>
                </tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['bill_number']}</td>
                    <td>{$row['customer_name']}</td>
                    <td>{$row['contact_number']}</td>
                    <td>₹{$row['total_amount']}</td>
                    <td>{$row['payment_method']}</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No records found for the selected date.";
    }
} else {
}
?>