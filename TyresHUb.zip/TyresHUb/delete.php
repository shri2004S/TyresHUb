<?php
include 'dbconn.php'; // Include your database connection file

if (isset($_GET['bill_number']) && !empty($_GET['bill_number'])) {
    $bill_number_to_delete = trim($_GET['bill_number']);

    // Prepare an SQL DELETE statement
    $sql = "DELETE FROM bill WHERE bill_number = ?";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind the bill number parameter
    $stmt->bind_param("s", $bill_number_to_delete);

    // Execute the statement
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Delete Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
            echo "<div class='container mt-5'><div class='alert alert-success' role='alert'>";
            echo "Bill <b>" . htmlspecialchars($bill_number_to_delete) . "</b> deleted successfully.";
            echo "</div><a href='search.php' class='btn btn-primary'>Back to Search</a></div></body></html>";
        } else {
            echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Delete Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
            echo "<div class='container mt-5'><div class='alert alert-info' role='alert'>";
            echo "No bill found with number <b>" . htmlspecialchars($bill_number_to_delete) . "</b>, or it was already deleted.";
            echo "</div><a href='search.php' class='btn btn-primary'>Back to Search</a></div></body></html>";
        }
    } else {
        echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Delete Status</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'></head><body>";
        echo "<div class='container mt-5'><div class='alert alert-danger' role='alert'>";
        echo "Error deleting record: " . htmlspecialchars($stmt->error);
        echo "</div><a href='search.php' class='btn btn-primary'>Back to Search</a></div></body></html>";
    }

    $stmt->close();
} else {
    // If bill_number is not provided, redirect to search page or show an error
    header('Location: search.php');
    exit();
}

$conn->close(); // Close the database connection
?>