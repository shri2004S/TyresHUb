<?php
/**
 * Database Connection File
 *
 * Establishes a connection to the database and handles connection errors.
 * This file should be included in any script that needs to access the database.
 */

// --- Database Configuration ---
// Replace with your actual database credentials.
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'your_db_username');
define('DB_PASSWORD', 'your_db_password');
define('DB_NAME', 'your_db_name');

// --- Establish the Connection ---
// Create a new mysqli object to connect to the database.
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// --- Check Connection ---
// If the connection fails, terminate the script and display an error message.
if ($conn->connect_error) {
    // In a production environment, you might want to log this error instead of displaying it.
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set to utf8mb4 for full Unicode support.
$conn->set_charset("utf8mb4");
?>