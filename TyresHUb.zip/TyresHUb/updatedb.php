<?php
include 'dbconn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $original = $_POST['original_bill_number'];
    $bill_number = $_POST['bill_number'];
    $billing_date = $_POST['billing_date'];
    $customer_name = $_POST['customer_name'];
    $contact_number = $_POST['contact_number'];
    $brand1 = $_POST['brand1'];
    $model1 = $_POST['model1'];
    $qty1 = $_POST['qty1'];
    $price1 = $_POST['price1'];
    $subtotal1 = $_POST['subtotal1'];
    $brand2 = $_POST['brand2'];
    $model2 = $_POST['model2'];
    $qty2 = $_POST['qty2'];
    $price2 = $_POST['price2'];
    $subtotal2 = $_POST['subtotal2'];
    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method'];

    $stmt = $conn->prepare("UPDATE bill SET bill_number=?, billing_date=?, customer_name=?, contact_number=?, brand1=?, model1=?, qty1=?, price1=?, subtotal1=?, brand2=?, model2=?, qty2=?, price2=?, subtotal2=?, total_amount=?, payment_method=? WHERE bill_number=?");
    $stmt->bind_param("sssssssssssssssss", $bill_number, $billing_date, $customer_name, $contact_number, $brand1, $model1, $qty1, $price1, $subtotal1, $brand2, $model2, $qty2, $price2, $subtotal2, $total_amount, $payment_method, $original);

    if (isset($_GET['bill_number'])) {
    $bill_number = $_GET['bill_number'];
    
    $stmt = $conn->prepare("SELECT * FROM bill WHERE bill_number = ?");
    $stmt->bind_param("s", $bill_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        echo "Bill not found.";
        exit;
    }
    $stmt->close();
} else {
    echo "No bill number provided.";
    exit;
}
}
?>