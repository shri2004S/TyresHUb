<?php
session_start();

// Hardcoded admin credentials
$admin_username = "admin";
$admin_password = "123";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin'] = $username;
        header("Location: index.php
        
        "); // or index.php
        exit();
    } else {
        echo "<script>alert('Invalid username or password'); window.location.href='login.php';</script>";
        exit();
    }
}
?>
