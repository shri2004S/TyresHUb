<?php
include 'dbconn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - The Perfect Tyres</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f8f9fa;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .login-box {
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      max-width: 900px;
      width: 100%;
    }

    .login-form {
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }

    .login-form h2 {
      font-weight: bold;
      margin-bottom: 30px;
    }

    .login-img {
      height: 100%;
      object-fit: cover;
      width: 100%;
    }

    .form-control {
      border-radius: 10px;
      text-align: center; /* ✅ center text inside input */
    }

    .btn-login {
      width: 100%;
      border-radius: 10px;
      padding: 10px;
    }

    @media (max-width: 768px) {
      .login-img {
        display: none;
      }
    }
  </style>
</head>
<body>
<form action="logindb.php" method="POST">
<div class="container">
  <div class="row login-box">
    
    <!-- Left Side: Image -->
    <div class="col-md-6 p-0">
      <img src="img/tyres13.png" alt="Login Image" class="login-img" />
    </div>

    <!-- Right Side: Login Form -->
    <div class="col-md-6 login-form">
      <h2>Login</h2>
      <form action="login.php" method="POST" style="width: 100%; max-width: 350px;">
        <div class="mb-3">
          <input type="text" class="form-control" name="username" placeholder="Enter username" required />
        </div>
        <div class="mb-4">
          <input type="password" class="form-control" name="password" placeholder="Enter password" required />
        </div>
        <button type="submit" class="btn btn-primary btn-login">Login</button>
      </form>
    </div>

  </div>
</div>

</body>
</html>
