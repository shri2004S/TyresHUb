<?php
include 'dbconn.php';

$month = $_POST['month'];
$year = $_POST['year'];

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Sales_Report_{$month}_{$year}.xls");
header("Pragma: no-cache");
header("Expires: 0");

$month_name = date("F", mktime(0, 0, 0, $month, 10));

echo "<table border='1'>";
echo "<tr><th colspan='4'>The Perfect Tyres - Monthly Sales Report ({$month_name} {$year})</th></tr>";

$stmt_total = $conn->prepare("SELECT SUM(total_amount) AS monthly_total FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ?");
$stmt_total->bind_param("ii", $year, $month);
$stmt_total->execute();
$result_total = $stmt_total->get_result();
$monthly_total_sales = 0;
if ($row = $result_total->fetch_assoc()) {
    $monthly_total_sales = $row['monthly_total'] ?? 0;
}
$stmt_total->close();

echo "<tr><td colspan='4'><b>Total Sales: ₹" . number_format($monthly_total_sales, 2) . "</b></td></tr>";

$stmt = $conn->prepare("
    SELECT brand, model, SUM(qty) AS total_qty, SUM(subtotal) AS total_subtotal
    FROM (
        SELECT brand1 AS brand, model1 AS model, qty1 AS qty, subtotal1 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand1 IS NOT NULL
        UNION ALL
        SELECT brand2 AS brand, model2 AS model, qty2 AS qty, subtotal2 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand2 IS NOT NULL
    ) AS combined
    GROUP BY brand, model
    ORDER BY total_qty DESC
");
$stmt->bind_param("iiii", $year, $month, $year, $month);
$stmt->execute();
$result = $stmt->get_result();

echo "<tr><th>Brand</th><th>Model</th><th>Qty</th><th>Total (₹)</th></tr>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['brand']}</td>
            <td>{$row['model']}</td>
            <td>{$row['total_qty']}</td>
            <td>" . number_format($row['total_subtotal'], 2) . "</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='4'>No records found</td></tr>";
}
echo "</table>";

$conn->close();
?>
