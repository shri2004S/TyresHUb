<?php
include 'dbconn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tyre Shop Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6; /* Light gray background */
        }
        /* Custom scrollbar for better aesthetics */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #e0e0e0;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .dashboard-section {
            display: none; /* Hidden by default */
        }
        .dashboard-section.active {
            display: block; /* Show active section */
        }
        /* Basic styling for tables (kept for general styling, though no tables are left in this version) */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background-color: #edf2f7;
            font-weight: 600;
            color: #4a5568;
        }
        /* Modal styling */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            width: 90%;
            max-width: 500px;
            position: relative;
        }
        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
            cursor: pointer;
        }
        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body class="flex min-h-screen">

    <div id="dashboard-layout" class="flex flex-1">
        <main class="flex-1 p-8 overflow-y-auto">
            <div class="bg-white p-8 rounded-lg shadow-lg min-h-full">
                <section id="dashboard-overview" class="dashboard-section active">
                    <h1 class="text-4xl font-bold text-gray-800 mb-6">Admin  Panel</h1>
                    <p class="text-gray-600 mb-8">Welcome to the Tyre Shop Admin Panel. </p>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div class="bg-blue-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-blue-800">Total Products</h3>
                                <p class="text-3xl font-bold text-blue-900 mt-2">150</p>
                            </div>
                            <svg class="w-12 h-12 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        </div>
                        <div class="bg-green-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-green-800">Tyres in Stock</h3>
                                <p class="text-3xl font-bold text-green-900 mt-2">850</p>
                            </div>
                            <svg class="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
                        </div>
                        <div class="bg-yellow-100 p-6 rounded-lg shadow-md flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-semibold text-yellow-800">Today's Sales</h3>
                                <p class="text-3xl font-bold text-yellow-900 mt-2">₹ 15,000</p>
                            </div>
                            <svg class="w-12 h-12 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V6m0 6v2m0 6v2"></path></svg>
                        </div>
                    </div>

                    <div class="mt-10">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <button class="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200"> <a href="add.php"> Add New Tyre</a></button>
                            <button class="bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200">Update Stock</button>
                            <button class="bg-purple-500 hover:bg-purple-600 text-white font-bold py-3 px-4 rounded-md shadow-md transition duration-200">Generate Bill</button>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <div id="custom-modal" class="modal hidden">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h3 id="modal-title" class="text-xl font-semibold mb-4"></h3>
            <p id="modal-message" class="mb-6"></p>
            <div id="modal-actions" class="flex justify-end gap-3">
                </div>
        </div>
    </div>

    <script>
        // Custom Modal Functions
        const customModal = document.getElementById('custom-modal');
        const modalTitle = document.getElementById('modal-title');
        const modalMessage = document.getElementById('modal-message');
        const modalActions = document.getElementById('modal-actions');

        function showModal(title, message, type, confirmCallback = null) {
            modalTitle.textContent = title;
            modalMessage.textContent = message;
            modalActions.innerHTML = ''; // Clear previous buttons

            if (type === 'alert') {
                const okButton = document.createElement('button');
                okButton.textContent = 'OK';
                okButton.className = 'bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                okButton.onclick = closeModal;
                modalActions.appendChild(okButton);
            } else if (type === 'confirm') {
                const cancelButton = document.createElement('button');
                cancelButton.textContent = 'Cancel';
                cancelButton.className = 'bg-gray-400 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                cancelButton.onclick = closeModal;

                const confirmButton = document.createElement('button');
                confirmButton.textContent = 'Confirm';
                confirmButton.className = 'bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-200';
                confirmButton.onclick = () => {
                    if (confirmCallback) {
                        confirmCallback();
                    }
                    closeModal();
                };
                modalActions.appendChild(cancelButton);
                modalActions.appendChild(confirmButton);
            }

            customModal.classList.remove('hidden');
        }

        function closeModal() {
            customModal.classList.add('hidden');
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == customModal) {
                closeModal();
            }
        }
    </script>
</body>
</html>