<?php
// addproduct.php
include 'dbconn.php'; // Ensure this path is correct and dbconn.php establishes a valid $conn

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $brand = $_POST['brand'] ?? '';
    $model = $_POST['model'] ?? '';
    $size = $_POST['size'] ?? '';
    $price = $_POST['price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;
    $type = $_POST['type'] ?? '';

    // --- Basic input validation ---
    if (empty($brand) || empty($model) || !is_numeric($price) || !is_numeric($stock) || $price < 0 || $stock < 0) {
        header("Location: product_management.php?error=validation_failed");
        if ($conn) $conn->close();
        exit();
    }

    // Prepare the SQL statement
    // Note: The table name in your product_management.php is 'tyres', but in your previous snippet it was 'alltyres'.
    // I'm using 'tyres' here to match product_management.php. Adjust if 'alltyres' is correct.
    $stmt = $conn->prepare("INSERT INTO alltyres (brand, model, size, price, stock, type) VALUES (?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        error_log("Failed to prepare statement in addproduct.php: " . $conn->error);
        header("Location: product_management.php?error=db_prepare_failed&sql_debug_error=" . urlencode($conn->error));
        if ($conn) $conn->close();
        exit();
    }

    // "sssdis" -> s=string, d=double, i=integer
    $stmt->bind_param("sssdis", $brand, $model, $size, $price, $stock, $type);

    if ($stmt->execute()) {
        header("Location: product_management.php?success=added");
        exit();
    } else {
        error_log("Failed to execute statement in addproduct.php: " . $stmt->error);
        header("Location: product_management.php?error=db_execute_failed&sql_debug_error=" . urlencode($stmt->error));
        exit();
    }

    $stmt->close();
} else {
    // If someone tries to access addproduct.php directly via GET request
    header("Location: product_management.php");
    exit();
}

if ($conn) {
    $conn->close();
}
?>