<?php
require 'dompdf/autoload.inc.php'; // Include Dompdf

use Dompdf\Dompdf;


include 'dbconn.php'; // Your database connection

// Get month & year from POST
$month = $_POST['month'];
$year = $_POST['year'];

// Fetch sales data
$monthly_total_sales = 0;
$tyre_sales_breakdown = [];

$stmt_total = $conn->prepare("SELECT SUM(total_amount) AS monthly_total FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ?");
$stmt_total->bind_param("ii", $year, $month);
$stmt_total->execute();
$result_total = $stmt_total->get_result();
if ($result_total && $row_total = $result_total->fetch_assoc()) {
    $monthly_total_sales = $row_total['monthly_total'] ?? 0;
}
$stmt_total->close();

$stmt_breakdown = $conn->prepare("
    SELECT brand, model, SUM(qty) AS total_qty, SUM(subtotal) AS total_subtotal
    FROM (
        SELECT brand1 AS brand, model1 AS model, qty1 AS qty, subtotal1 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand1 IS NOT NULL AND brand1 != ''
        UNION ALL
        SELECT brand2 AS brand, model2 AS model, qty2 AS qty, subtotal2 AS subtotal
        FROM bill WHERE YEAR(billing_date) = ? AND MONTH(billing_date) = ? AND brand2 IS NOT NULL AND brand2 != ''
    ) AS combined_tyres
    GROUP BY brand, model
    ORDER BY total_qty DESC, brand ASC, model ASC;
");
$stmt_breakdown->bind_param("iiii", $year, $month, $year, $month);
$stmt_breakdown->execute();
$result_breakdown = $stmt_breakdown->get_result();
while ($row = $result_breakdown->fetch_assoc()) {
    $tyre_sales_breakdown[] = $row;
}
$stmt_breakdown->close();
$conn->close();

// Generate PDF HTML
$month_name = date("F", mktime(0, 0, 0, $month, 10));
$html = "
<h2 style='text-align:center;'>The Perfect Tyres</h2>
<h3 style='text-align:center;'>Monthly Sales Report - {$month_name} {$year}</h3>
<hr>
<h4>Total Sales: ₹" . number_format($monthly_total_sales, 2) . "</h4>
<table border='1' cellspacing='0' cellpadding='8' width='100%'>
    <thead>
        <tr style='background-color:#f2f2f2;'>
            <th>Brand</th>
            <th>Model</th>
            <th>Quantity</th>
            <th>Total Amount (₹)</th>
        </tr>
    </thead>
    <tbody>";
if (!empty($tyre_sales_breakdown)) {
    foreach ($tyre_sales_breakdown as $item) {
        $html .= "
        <tr>
            <td>{$item['brand']}</td>
            <td>{$item['model']}</td>
            <td>{$item['total_qty']}</td>
            <td>" . number_format($item['total_subtotal'], 2) . "</td>
        </tr>";
    }
} else {
    $html .= "<tr><td colspan='4' style='text-align:center;'>No data available</td></tr>";
}
$html .= "</tbody></table>";

// Load Dompdf
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output to browser (as download)
$dompdf->stream("Monthly_Sales_{$month}_{$year}.pdf", array("Attachment" => true)); // true = download
?>
